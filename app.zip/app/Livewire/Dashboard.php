<?php

namespace App\Livewire;

use App\Models\Form;
use App\Models\Answers;
use Livewire\Component;
use Illuminate\Support\Facades\DB;
use App\Models\Responses as Response;
use App\Models\Responden as Responden;

use App\Exports\ScoringExport;
use App\Exports\FormResponseExport;
use App\Exports\RekapExport;
use App\Exports\ScoringPersonalExport;
use Maatwebsite\Excel\Facades\Excel;

class Dashboard extends Component
{
    public $forms;
    public $responseData;
    public $responden;
    public $selectedPlacement = 'pre-test-website';
    public $defaultSelectedForm;
    public $selectedForm = null;
    public $selectedFormName = null;
    public $confirmDelete;
    
    public $showAllScoring = false;

    protected $listeners = ['refreshComponent' => 'loadData'];

    public $uniqueFormId;
    public $uniqueAnswers;

    public $groupedResponses = [];
    public $groupedAllResponses=[];
    public $groupedAllResponsesScoring=[];

    public $groupedResponsesForRekap=[];
    public $groupedResponsesForSingleForm=[];
    public $columns;
    public $cellMatrix;

    public $rekapScoring = [];
    public $scoreAnswer;

    public function mount()
    {
        try{
            $this->responden = Responden::count();
            $this->forms = Form::pluck('id','form_name');

            $this->scoreAnswer = Answers::with('question.section.form')
                ->get()
                ->groupBy(fn ($answer) => $answer->question->section->form->id)
                ->map(function ($answers, $formId) {

                    $maxScore = $answers
                        ->groupBy('question_id') // 1️⃣ group per question
                        ->map(fn ($questionAnswers) => $questionAnswers->max('value')) // 2️⃣ ambil value tertinggi
                        ->sum(); // 3️⃣ jumlahkan

                    return [
                        'form_id'   => $formId,
                        'max_score' => $maxScore,
                    ];
                });

            $this->calculateTotalResponses();
            $this->uniqueFormId = Response::whereHas('answer.question.section.form')
                ->distinct()
                ->pluck('form_id');
            //dd($this->uniqueFormId);
            
            $this->uniqueAnswers = Answers::whereHas('question.section.form', function ($query) {
                $query->whereIn('id', $this->uniqueFormId);
            })
            ->with('question.section.form')
            ->get()
            ->groupBy(fn($answer) => $answer->question->section->form->id)
            ->map(function($answers) {
                return $answers->map(function($a) {
                    // Kita kumpulkan semua field yang dibutuhkan
                    return [
                        'id'           => $a->id,
                        'answer'       => $a->answer,
                        'answerImage'  => $a->image,
                    ];
                })
                // Unik berdasarkan kombinasi string answer DAN string answerImage
                ->unique(function ($item) {
                    return $item['answer'] . $item['answerImage'];
                })
                ->values();
            });
                    
            $allResponses = Response::query()
                ->select([
                    'responses.id',
                    'responses.form_id',
                    'responses.attempt',
                    'responses.uuid',

                    'answers.id as answerId',
                    'answers.answer',
                    'answers.image as answerImage',
                    'answers.value',

                    'questions.question',
                    'questions.id as questionId',
                    'questions.image as questionImage',

                    'forms.form_name',
                    'forms.placement',

                    'respondens.email',
                ])
                ->selectRaw("
                    COALESCE(respondens.email, CONCAT('uuid:', responses.uuid)) as user_key
                ")
                ->leftJoin('answers', 'answers.id', '=', 'responses.answer_id')
                ->leftJoin('questions', 'questions.id', '=', 'answers.question_id')
                ->leftJoin('sections', 'sections.id', '=', 'questions.section_id')
                ->leftJoin('forms', 'forms.id', '=', 'sections.form_id')
                ->leftJoin('respondens', 'respondens.id', '=', 'responses.responden_id')
                ->toBase()
                ->get();

            // 🔥 DATA GLOBAL
            $this->buildRekapScoring(
                collect($allResponses)->groupBy('form_name')
            );

            $this->ScoringPersonal($allResponses);
            $this->loadData();
        }catch(\Exception $e){
            session()->flash('error', $e->getMessage());
        }
    }

    //------------------- SCORING PERSONAL ---------------------------
    public function ScoringPersonal($responses)
    {
        $this->groupedAllResponsesScoring =
            collect($responses)
                    ->groupBy(fn ($r) => $r->user_key)
                    ->sortKeysUsing(function ($a, $b) {
                        $aIsUuid = str_starts_with($a, 'uuid:');
                        $bIsUuid = str_starts_with($b, 'uuid:');

                        if ($aIsUuid && !$bIsUuid) return 1;
                        if (!$aIsUuid && $bIsUuid) return -1;
                        return strcmp($a, $b);
                    })
                    ->map(function ($responsesByUser) {
                    
                        return $responsesByUser
                            ->groupBy(fn ($r) => $r->placement)
                            ->map(function ($placementGroup) {

                                return $placementGroup
                                    ->groupBy(fn ($r) => $r->form_id)
                                    ->map(function ($responses, $formId) {

                                        $groupedByQuestion = $responses
                                            // 1. Grouping berdasarkan ID agar pertanyaan yang teksnya sama tapi ID beda tetap terpisah
                                            ->groupBy(fn ($r) => $r->questionId) 
                                            ->map(function ($q) {
                                                return [
                                                    // 2. Masukkan teks pertanyaan ke dalam array data
                                                    'id'  => $q->first()->id, 
                                                    'question'  => $q->first()->question, 
                                                    'questionImage' => $q->first()->questionImage ?? null,
                                                    'attempts'      => $q->groupBy(fn ($r) => $r->attempt)
                                                ];
                                            });

                                        $totalScoreByAttempt = $responses
                                            ->groupBy(fn ($r) => $r->attempt)
                                            ->map(fn ($group) =>
                                                $group->sum(fn ($r) => $r->value ?? 0)
                                            );

                                        return [
                                            'form_id'     => $formId,
                                            'form_name'   => $responses->first()->form_name,
                                            'items'       => $groupedByQuestion,
                                            'total_score' => $totalScoreByAttempt,
                                            'max_score'   => $this->scoreAnswer[$formId]['max_score'] ?? 0,
                                        ];
                                    });
                            });
                    });
    }

    public function toggleShowAllScoring(){
        $this->showAllScoring = !$this->showAllScoring;
    }

    //-----------------------------------------------------------------
    //---------------------- SINGLE FORM ------------------------------
    public function ResponseForSingleForm($responses)
    {
        $this->groupedResponsesForSingleForm = collect($responses)
            ->groupBy(fn ($r) => $r->question_id);
       
        $this->columns = collect($responses)
            ->map(function ($r) {
                $keyBase = $r->email
                    ? 'email:' . $r->email
                    : 'uuid:' . $r->uuid;

                return [
                    'email'      => $r->email,
                    'uuid'       => $r->uuid,
                    'attempt'    => $r->attempt,
                    'created_at' => $r->created_at,
                    'key'        => $keyBase . '-attempt:' . $r->attempt,
                ];
            })
            ->groupBy(fn ($c) => $c['email'] ?? $c['uuid'])
            ->map(fn ($group) => $group->sortBy('attempt'))
            ->flatten(1)
            ->unique('key')
            ->sortBy(fn ($c) => $c['email'] ? 0 : 1) // email dulu, uuid belakang
            ->values();

        $this->cellMatrix = collect($responses)
            ->groupBy(fn ($r) => $r->question_id)
            ->map(function ($responsesPerQuestion) {

                return $responsesPerQuestion
                    ->groupBy(function ($r) {
                        $keyBase = $r->email
                            ? 'email:' . $r->email
                            : 'uuid:' . $r->uuid;

                        return $keyBase . '-attempt:' . $r->attempt;
                    });
            });
    }

    
    //-----------------------------------------------------------
    //----------------------- REKAP SCORING ------------------------------
    public function buildRekapScoring($responses)
    {  
        $this->rekapScoring = collect($responses) 
            ->mapWithKeys(function ($items, $formName) {
                
                $formId = $items->first()->form_id ?? null;
                
                if (!$formId) return [];
                $answers = $this->uniqueAnswers[$formId] ?? collect();
                
                // skip kalau opsi jawaban terlalu banyak
                if ($answers->count() > 6) {
                    return [];
                }

                // 🔥 group per pertanyaan (string biasa)
                
                $rows = collect($items)
                    ->groupBy('question')
                    ->map(function ($questionResponses, $questionText) use ($answers) {
                        $scores = $answers
                            ->mapWithKeys(fn ($a) => [$a['answer'] . $a['answerImage'] => 0])
                            ->toArray();

                        foreach ($questionResponses as $r) {
                            
                            $ans = $r->answer ?? null;
                            $img = $r->answerImage ?? null;
                            $val = $ans.$img;
                            if ($val !== null && isset($scores[$val])) {
                                $scores[$val]++;
                            }
                        }

                        $questionImage = $questionResponses->first()->questionImage ?? null;
                        $questionId = $questionResponses->first()->id ?? null;

                        return [
                            'id' => $questionId,
                            'question' => $questionText,
                            'questionImage' => $questionImage,
                            'scores'   => $scores,
                        ];
                    })
                    ->values();

                return [
                    $formName => [
                        'answers' => $answers->values(),
                        'rows'    => $rows,
                    ]
                ];
            })
            ->toArray();
            
    }

    //--------------------------------------------------------------
    // --------------------------- TOTAL RESPONDEN & RESPONSE ------------------------------------------
    private function buildStats($responses, $formIds)
    {
        $filtered = $responses->whereIn('form_id', $formIds);

        return [
            'responden' => collect([
                'count'    => $filtered->unique('identifier')->count(),
                'email'    => $filtered->where('attempt', '!=', 0)->unique('identifier')->count(),
                'no-email' => $filtered->where('attempt', 0)->unique('identifier')->count(),
            ]),
            'responses' => collect([
                'count' => $filtered->sum('total'),
            ])
        ];
    }

    private function countFilledForms($rows, $formIds)
    {
        $filtered = $rows->whereIn('form_id', $formIds);
        $unique = $filtered->unique(fn ($r) => $r->identifier.'-'.$r->form_id);

        return [
            'count'    => $unique->count(),
            'email'    => $unique->where('attempt', '!=', 0)->count(),
            'no-email' => $unique->where('attempt', 0)->count(),
        ];
    }

    public  function calculateTotalResponses()
    {
        try{
           $formIds = Form::select('id', 'placement')->get()->groupBy('placement');

            $websiteForms = collect([
                'pre'  => $formIds['pre-test-website']?->pluck('id') ?? collect(),
                'post' => $formIds['post-test-website']?->pluck('id') ?? collect(),
            ]);

            $emodulForms = collect([
                'pre'  => $formIds['pre-test-emodul']?->pluck('id') ?? collect(),
                'post' => $formIds['post-test-emodul']?->pluck('id') ?? collect(),
            ]);
            
           $baseQuery = Response::selectRaw("
                COALESCE(responden_id, uuid) as identifier,
                form_id,
                attempt,
                COUNT(*) as total
            ")
            ->groupBy('identifier', 'form_id', 'attempt')
            ->get();
           
            $this->groupedResponses = collect([
                'website' => [
                    'responden' => $this->buildStats($baseQuery, $websiteForms->flatten())['responden'],
                    'responses' => collect([
                        'count' => $baseQuery->whereIn('form_id', $emodulForms->flatten())->unique(fn ($r) => $r->identifier.'-'.$r->form_id)->count(),
                        'pre-test'  => $this->countFilledForms($baseQuery, $websiteForms['pre']),
                        'post-test' => $this->countFilledForms($baseQuery, $websiteForms['post']),
                    ]),
                ],

                'emodul' => [
                    'responden' => $this->buildStats($baseQuery, $emodulForms->flatten())['responden'],
                    'responses' => collect([
                        'count' => $baseQuery->whereIn('form_id', $emodulForms->flatten())->unique(fn ($r) => $r->identifier.'-'.$r->form_id)->count(),
                        'pre-test'  => $this->countFilledForms($baseQuery, $emodulForms['pre']),
                        'post-test' => $this->countFilledForms($baseQuery, $emodulForms['post']),
                    ]),
                ],
            ]);

        }catch(\Exception $e){
            session()->flash('error', $e->getMessage());
        }
    }
    // -------------------------------------------------------------------------------------------

    public function loadData()
    {
        try {
            $query = Response::query()
                ->select([
                    'responses.id',
                    'responses.form_id',
                    'responses.attempt',
                    'responses.uuid',
                    'responses.created_at',

                    'answers.answer',
                    'answers.value',
                    'answers.image as answerImage',

                    'questions.id as question_id',
                    'questions.question',
                    'questions.image as questionImage',

                    'forms.form_name',
                    'forms.placement',

                    'respondens.email',
                ])
                ->leftJoin('answers', 'answers.id', '=', 'responses.answer_id')
                ->leftJoin('questions', 'questions.id', '=', 'answers.question_id')
                ->leftJoin('sections', 'sections.id', '=', 'questions.section_id')
                ->leftJoin('forms', 'forms.id', '=', 'sections.form_id')
                ->leftJoin('respondens', 'respondens.id', '=', 'responses.responden_id');

            // 🔥 FILTER SEARCH
            if ($this->selectedPlacement) {
                $formId = Form::where('placement', $this->selectedPlacement)
                    ->orderBy('created_at')
                    ->value('id');

                if ($formId) {
                    $query->where('responses.form_id', $formId);
                }
            }

            if ($this->selectedForm) {
                $query->where('forms.id', $this->selectedForm);
            }

            // 🔥 DATA SEARCH
            $responses = $query->toBase()->get();
            if(!$responses->isEmpty()){
                $this->responseData = (object) [
                    'form_id'   => $responses->first()->form_id, 
                    'form_name' => $responses->first()->form_name
                ];
            }else{
                
                $this->responseData = null;
            }

            // 🔥 HANYA UNTUK SEARCH
            $this->ResponseForSingleForm($responses);
        
        } catch (\Throwable $e) {
            session()->flash('error', $e->getMessage());
            $this->responseData = null;
        }
    }

     public function exportExcel($type, $formId)
    {
         if ($type === 'response') {
            
            $data = Response::with([
                'responden',
                'answer.question.section.form'
            ])
            ->whereHas('form', fn($q) => $q->where('id', (int) $formId))
            ->get();

            return Excel::download(
                new FormResponseExport($data),
                "responses-{$formId}.xlsx"
            );
        }

        else if ($type === 'rekap') {

            $forms = Form::with('sections.questions.answers')->get();

            // filter form yang jawaban unik <= 6
            $validForms = $forms->filter(function($form) {
                $unique = $form->sections
                    ->flatMap->questions
                    ->flatMap->answers
                    ->pluck('value')
                    ->unique();

                return $unique->count() <= 6;
            });

            return Excel::download(
                new RekapExport($validForms),
                "rekap.xlsx"
            );
        }

        else if ($type === 'scoring') {

            $data = Response::with(['responden', 'answer.question.section.form'])->get();

            // Group: EMAIL → FORM
            $groupedByEmail = $data
                ->groupBy('responden.email')
                ->map(function ($rows) {
                    return $rows->groupBy('answer.question.section.form_id');
                });

            return Excel::download(
                new ScoringExport($groupedByEmail),
                "scoring.xlsx"
            );
        }

        else if ($type === 'scoringPersonal') {
            $data = Response::with(['responden', 'answer.question.section.form'])
                ->whereHas('responden', fn ($q) => $q->where('email', $formId))
                ->get();

            // Grouping per form
            $groupedForms = $data->groupBy('answer.question.section.form_id');

            return Excel::download(
                new ScoringPersonalExport($groupedForms),
                "scoring-personal-{$formId}.xlsx"
            );
        }

        abort(404);
    }

    public function deleteResponse($formId)
    {
        try {
            if($this->confirmDelete && strtoLower($this->confirmDelete) === 'hapus data response') {
                Response::where('form_id', $formId)->delete();
                session()->flash('success', 'Response berhasil dihapus.');
                return redirect()->route('dashboard');
            }else{
                session()->flash('error', 'Anda harus mengetikkan "hapus data response" untuk menghapus semua responden.');
                return;
            }
        } catch (\Exception $e) {
            session()->flash('error', $e->getMessage());
        }
    }

    public function render()
    {
        return view('livewire.dashboard');
    }
}
