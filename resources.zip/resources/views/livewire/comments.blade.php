<div class="sm:ml-64">
    <div class="comments-section bg-slate-100 dark:bg-slate-600 rounded p-4 shadow-md" x-data="{ open: @entangle('isModalOpen') }">
    <x-loading wire:loading.flex />
        <div class="hidden" id='jsLoader'>
            <x-loading />
        </div>
        <script>
            document.getElementById('jsLoader').classList.remove('hidden');
            setTimeout(()=>{
                document.getElementById('jsLoader').classList.add('hidden');
            },2750)
        </script>
        <h2 class="text-center mb-4 text-2xl font-bold text-black dark:text-white">Comments Section</h2>
        
        <div class="w-100 flex justify-center">
            <div class="dark:bg-indigo-600/60 bg-blue-300 p-4 rounded-md w-1/2 shadow-sm mb-3">
                <div class="mb-5">
                    <textarea wire:model="comment" 
                            class="bg-gray-50 border dark:border-gray-300 text-gray-900 text-sm rounded-lg dark:focus:ring-blue-500 
                                dark:focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 border-gray-600 placeholder-gray-400 
                                dark:text-white focus:ring-blue-500 focus:border-blue-500" 

                            placeholder="Tulis komentar..." required></textarea>
                </div>
                <button type="submit" wire:click="store('new')" class="text-white dark:bg-blue-500 dark:hover:bg-blue-600 focus:ring-4 dark:focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-blue-800">Kirim Komentar</button>
            </div>
        </div>

        <hr>
        @if(session('success'))
            <div class="fixed top-5 left-1/2 transform -translate-x-1/2 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded shadow-lg z-50">
                <div class="flex items-center justify-between gap-4">
                    <span>{{ session('success') }}</span>
                    <button type="button" class="text-green-700 hover:text-green-900" onclick="this.parentElement.parentElement.remove()">
                        &times;
                    </button>
                </div>
            </div>
        @endif

        @if (session('error'))
            <div class="fixed top-5 left-1/2 transform -translate-x-1/2 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded shadow-lg z-50">
                <div class="flex items-center justify-between gap-4">
                    <span>{{ session('error') }}</span>
                    <button type="button" class="text-red-700 hover:text-red-900" onclick="this.parentElement.parentElement.remove()">
                        &times;
                    </button>
                </div>
            </div>
        @endif
        @foreach ($comments->where('parent_id', null) as $comment)
            <div class="p-6 border rounded-lg shadow-md bg-transparent border-gray-400 mt-2">
                <div class="p-4 border dark:border-slate-300 rounded-lg border-gray-700 {{ $comment->is_admin ? 'dark:bg-indigo-900 bg-blue-200' : 'bg-white dark:bg-slate-600' }}">
                    <strong class="dark:text-white text-black">{{ $comment->name }}
                        @if ($comment->is_admin)
                            <span class="text-blue-600 dark:text-blue-400">(admin)</span>
                        @endif
                    </strong>
                    <p class="dark:text-white text-black">{{ $comment->comment }}</p>

                    <button class="reply-btn text-white bg-gradient-to-r from-blue-500 via-blue-600 to-blue-700 hover:bg-gradient-to-br focus:ring-4 focus:outline-none dark:focus:ring-blue-300 focus:ring-blue-800 font-medium rounded-lg text-sm px-3.5 py-1.5 text-center me-2 mb-2 mt-4" wire:click="edit({{ $comment->id }}, 'reply')">             
                        Reply
                    </button>

                    {{-- @dd($parent_id) --}}
                    @if ($comment->is_admin)
                        <button wire:click="edit({{ $comment->id }}, 'edit')"
                            class="text-violet-600 dark:text-blue-300 hover:underline mr-2 font-bold p-2">Edit</button>
                    @endif
                    <button wire:click="setStatsAction({{ $comment->id }}, 'delete')" class="text-red-500 font-bold p-2 hover:underline">Delete</button>
                </div>

                @if ($editingId == $comment->id)
                    <div class="my-4 dark:bg-slate-600 bg-white rounded-md p-4">
                        @if($state == 'edit')
                            <h3 class="text-lg font-semibold dark:text-white text-black">Edit Komentar</h3>
                        @else
                            <h3 class="text-lg font-semibold dark:text-white text-black">Balas Komentar</h3>
                        @endif
                            
                        <textarea wire:model="comment" class="form-textarea w-full mb-2 rounded-md dark:bg-slate-500 bg-white dark:text-white text-black" placeholder="Komentar"></textarea>

                        @if($state == 'reply')
                            <button wire:click="store('none')"
                                class="bg-green-500 text-white px-4 py-2 rounded">Simpan</button>
                        @elseif($state == 'edit')
                            <button wire:click="update"
                                class="bg-green-500 text-white px-4 py-2 rounded">Simpan</button>
                        @endif
                        <button wire:click="$set('editingId', null)"
                            class="bg-gray-300 text-black px-4 py-2 rounded ml-2">Batal</button>
                    </div>
                @endif
                    
                @foreach ($comment->replies as $reply)
                    <div class="p-6 border rounded-lg bg-gray-200 dark:bg-slate-700 border-gray-700">
                        <div class="p-4 border dark:border-slate-300 rounded-lg border-gray-700 {{ $reply->is_admin ? 'dark:bg-indigo-900 bg-blue-200' : 'bg-white dark:bg-slate-600' }}">
                            <strong class="dark:text-white text-black">{{ $reply->name }}
                                @if ($reply->is_admin)
                                    <span class="text-blue-600 dark:text-blue-400">(admin)</span>
                                @endif
                            </strong>
                            <p class="dark:text-white text-black">{{ $reply->comment }}</p>
                            
                            <button class="reply-btn text-white bg-gradient-to-r from-blue-500 via-blue-600 to-blue-700 hover:bg-gradient-to-br focus:ring-4 focus:outline-none dark:focus:ring-blue-300 focus:ring-blue-800 font-medium rounded-lg text-sm px-3.5 py-1.5 text-center me-2 mb-2 mt-4" wire:click="edit({{ $reply->id }}, 'reply')">            
                                Reply
                            </button>
        
                            @if ($reply->is_admin)
                                <button wire:click="edit({{ $reply->id }}, 'edit')"
                                    class="text-violet-600 dark:text-blue-300 hover:underline mr-2 font-bold p-2">Edit</button>
                            @endif
        
                            <button wire:click="setStatsAction({{ $reply->id }}, 'delete')"
                                class="text-red-500 font-bold p-2 hover:underline">Delete</button>

                            @if ($editingId == $reply->id)
                                <div class="my-4 dark:bg-slate-600 bg-white rounded-md p-4">
                                    @if($state == 'edit')
                                        <h3 class="text-lg font-semibold dark:text-white text-black">Edit Komentar</h3>
                                    @else
                                        <h3 class="text-lg font-semibold dark:text-white text-black">Balas Komentar</h3>
                                    @endif
                                        
                                    <textarea wire:model="comment" class="form-textarea w-full mb-2 rounded-md dark:bg-slate-600 bg-white dark:text-white text-black" placeholder="Komentar"></textarea>
    
                                    @if($state == 'reply')
                                        <button wire:click="store('none')"
                                            class="bg-green-500 text-white px-4 py-2 rounded">Simpan</button>
                                    @elseif($state == 'edit')
                                        <button wire:click="update"
                                            class="bg-green-500 text-white px-4 py-2 rounded">Simpan</button>
                                    @endif
                                    <button wire:click="$set('editingId', null)"
                                        class="bg-gray-300 text-black px-4 py-2 rounded ml-2">Batal</button>
                                </div>
                            @endif
                        </div>

                        @foreach ($reply->replies as $reply_replys)
                            <div class="p-6 border dark:border-gray-200 rounded-lg shadow-sm dark:bg-gray-800 border-gray-700 mt-2 ms-4 {{ $reply_replys->is_admin ? 'dark:bg-indigo-900 bg-blue-200' : 'bg-white dark:bg-slate-600' }}">
                                <div class="card-body">
                                    <strong class="dark:text-white text-black">{{ $reply_replys->name }}
                                        @if ($reply_replys->is_admin)
                                            <span  class="text-blue-600 dark:text-blue-400">(admin)</span>
                                        @endif
                                    </strong>
                                    <p class="dark:text-white text-black">{{ $reply_replys->comment }}</p>
                
                                    @if ($reply_replys->is_admin)
                                        <button wire:click="edit({{ $reply_replys->id }}, 'edit')"
                                            class="text-violet-600 dark:text-blue-300 hover:underline mr-2 font-bold p-2">Edit</button>
                                    @endif
                
                                    <button wire:click="setStatsAction({{ $reply_replys->id }}, 'delete')"
                                        class="text-red-500 font-bold p-2 hover:underline">Delete</button>

                                    @if ($editingId == $reply_replys->id)
                                        <div class="mt-4">
                                            <h3 class="text-lg font-semibold">Edit Komentar</h3>
                                            <textarea wire:model="comment" class="form-textarea w-full mb-2" placeholder="Komentar"></textarea>
                                            
                                            <button wire:click="update" class="bg-green-500 text-white px-4 py-2 rounded">Simpan</button>
                                            <button wire:click="$set('editingId', null)" class="bg-gray-300 text-black px-4 py-2 rounded ml-2">Batal</button>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                @endforeach
            </div>
        @endforeach

         <!-- MODAL -->
        <div x-show="open" x-transition x-cloak class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[999]">
            <div class="bg-white dark:bg-slate-800 rounded-lg p-3 lg:w-1/3 w-[70%] text-black dark:text-white">
                <div class="flex items-center justify-between p-4 md:p-5 border-b rounded-t border-gray-600 dark:border-gray-200">
                    <h3 class="text-xl font-bold mb-4">Hapus Comments</h3>
                    <button type="button" @click="open = false" class="text-gray-400 bg-transparent dark:hover:bg-gray-200 dark:hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center hover:bg-gray-600 hover:text-white">
                        <svg class="w-3 h-3" aria-hidden="true" fill="none" viewBox="0 0 14 14">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                </div>
                <div>
                    <div class="p-4 md:p-5 space-y-2">
                        <p>anda yakin ingin <span class="font-bold">MENGHAPUS</span> comment ini?</p>
                    </div>
                    <!-- Modal footer -->
                    <div class="flex items-center p-4 md:p-5 border-t dark:border-gray-200 rounded-b border-gray-600">
                        <button wire:click="delete({{ $commentId }})" class="block text-white bg-red-700 hover:bg-red-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center">Hapus</button>
                    </div>
            </div>
            </div>
        </div>
    </div>
</div>
