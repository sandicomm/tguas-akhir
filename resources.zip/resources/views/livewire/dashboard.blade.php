<!-- Main modal -->

<div>
    <div class="sm:ml-64 pt-4">
        <div class="hidden" id='jsLoader'>
            <x-loading />
        </div>
        <script>
            document.getElementById('jsLoader').classList.remove('hidden');
            setTimeout(()=>{
                document.getElementById('jsLoader').classList.add('hidden');
            },2750)
        </script>
        <div>
        @if(session('success'))
            <div class="fixed top-5 left-1/2 transform -translate-x-1/2 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded shadow-lg z-50">
                <div class="flex items-center justify-between gap-4">
                    <span>{{ session('success') }}</span>
                    <button type="button" class="text-green-700 hover:text-green-900" onclick="this.parentElement.parentElement.remove()">
                        &times;
                    </button>
                </div>
            </div>
        @endif

        @if (session('error'))
            <div class="fixed top-5 left-1/2 transform -translate-x-1/2 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded shadow-lg z-50">
                <div class="flex items-center justify-between gap-4">
                    <span>{{ session('error') }}</span>
                    <button type="button" class="text-red-700 hover:text-red-900" onclick="this.parentElement.parentElement.remove()">
                        &times;
                    </button>
                </div>
            </div>
        @endif
            <!-- ----------------------------- TOTAL RESPONDEN -------------------------------------- -->
            <div class="px-4 h-fit">
                <x-loading wire:loading.flex />  
                <div class="flex lg:text-2xl md:text-xl items-center justify-center flex-col gap-3 mb-4 rounded bg-white dark:bg-gray-800 p-4 shadow-md">
                    <p class="text-black dark:text-white">
                        Responden Yang Terdata
                    </p>
                    <p class="text-black dark:text-white">{{ $responden }}</p>
                </div>
               
                <div class="flex lg:flex-nowrap flex-wrap md:gap-3 gap-10 m-4 mb-12">
                    <div class="flex w-full h-fit items-center justify-start flex-col rounded-md bg-white dark:bg-gray-800 shadow-md">
                        <div class="text-center rounded bg-teal-400 w-full p-1">
                            <p class="lg:text-xl text-white">
                                Website
                            </p>
                        </div>
                        <div class="flex flex-row xl:flex-nowrap flex-wrap items-start justify-center w-full h-full">
                            <div class="py-4 text-center flex items-center justify-center flex-col rounded w-full h-full">
                                <p class="lg:text-xl text-black dark:text-white">
                                    Responden
                                </p>

                                <p class="lg:text-2xl text-black dark:text-white">{{ $groupedResponses['website']['responden']['count'] ?? '0' }}</p>

                                <div class="text-white mt-2 text-center flex flex-row items-center justify-center rounded bg-gradient-to-r from-blue-500 to-cyan-500 w-[85%] h-fit">
                                    <div class="py-2 text-center flex items-center justify-center flex-col rounded w-full h-full">
                                        <p class="xl:text-xl">
                                            Email
                                        </p>
                                        <p class="xl:text-2xl">{{ $groupedResponses['website']['responden']['email'] ?? '0' }}</p>
                                    </div>
                                    <div class="py-2 text-center flex items-center justify-center flex-col rounded w-full h-full">
                                        <p class="xl:text-xl">
                                            No-email
                                        </p>
                                        <p class="xl:text-2xl">{{ $groupedResponses['website']['responden']['no-email'] ?? '0' }}</p>
                                    </div>
                                </div>
                            </div>
                            <div class="py-4 text-center flex items-center justify-center flex-col rounded w-full h-full">
                                <p class="lg:text-xl text-black dark:text-white">
                                    Responses
                                </p>
                                <p class="lg:text-2xl text-black dark:text-white">{{ $groupedResponses['website']['responses']['count'] ?? '0' }}</p>

                                <div class="text-white mt-2 text-center flex flex-row items-center justify-center rounded bg-gradient-to-r from-blue-500 to-cyan-500 w-[90%] h-fit">
                                    <div class="py-2 text-center flex items-center justify-center flex-col rounded w-full h-full">
                                        <p class="xl:text-xl">
                                            Pre-Test
                                        </p>
                                        <p class="xl:text-2xl">{{ $groupedResponses['website']['responses']['pre-test']['count'] ?? '0' }}</p>

                                        <div class="py-1 px-2 text-black mt-2 flex flex-col items-center justify-center rounded bg-white w-[90%] h-fit">
                                            <table class="text-sm text-start w-full">
                                                <tr>
                                                    <td>email</td>
                                                    <td>{{ $groupedResponses['website']['responses']['pre-test']['email'] ?? '0' }}</td>
                                                </tr>
                                                <tr>
                                                    <td>no-email</td>
                                                    <td>{{ $groupedResponses['website']['responses']['pre-test']['no-email'] ?? '0' }}</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="py-2 text-center flex items-center justify-center flex-col rounded w-full h-full">
                                        <p class="xl:text-xl">
                                            Post-Test
                                        </p>
                                        <p class="xl:text-2xl">{{ $groupedResponses['website']['responses']['post-test']['count'] ?? '0' }}</p>
                                        <div class="py-1 px-2 text-black mt-2 flex flex-col items-center justify-center rounded bg-white w-[90%] h-fit">
                                            <table class="text-sm text-start w-full">
                                                <tr>
                                                    <td>email</td>
                                                    <td>{{ $groupedResponses['website']['responses']['post-test']['email'] ?? '0' }}</td>
                                                </tr>
                                                <tr>
                                                    <td>no-email</td>
                                                    <td>{{ $groupedResponses['website']['responses']['post-test']['no-email'] ?? '0'}}</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex w-full h-fit items-center justify-start flex-col rounded-md bg-gray-50 dark:bg-gray-800 shadow-md">
                        <div class="text-center rounded bg-teal-400 w-full p-1">
                            <p class="lg:text-xl text-white">
                                Emodul
                            </p>
                        </div>
                        <div class="flex flex-row xl:flex-nowrap flex-wrap items-start justify-center rounded-md w-full h-full bg-gray-50 dark:bg-gray-800">
                            <div class="py-4 text-center flex items-center justify-center flex-col w-full h-full">
                                <p class="lg:text-xl text-black dark:text-white">
                                    Responden
                                </p>

                                <p class="lg:text-2xl text-black dark:text-white">{{ $groupedResponses['emodul']['responden']['count'] ?? '0' }}</p>

                                <div class="text-white mt-2 text-center flex flex-row items-center justify-center rounded bg-gradient-to-r from-blue-500 to-cyan-500 w-[85%] h-fit">
                                    <div class="py-2 text-center flex items-center justify-center flex-col rounded w-full h-full">
                                        <p class="xl:text-xl">
                                            Email
                                        </p>
                                        <p class="xl:text-2xl">{{ $groupedResponses['emodul']['responden']['email'] ?? '0' }}</p>
                                    </div>
                                    <div class="py-2 text-center flex items-center justify-center flex-col rounded w-full h-full">
                                        <p class="xl:text-xl">
                                            No-email
                                        </p>
                                        <p class="xl:text-2xl">{{ $groupedResponses['emodul']['responden']['no-email'] ?? '0' }}</p>
                                    </div>
                                </div>
                            </div>
                            <div class="py-4 text-center flex items-center justify-center flex-col rounded w-full h-full">
                                <p class="lg:text-xl text-black dark:text-white">
                                    Responses
                                </p>
                                <p class="lg:text-2xl text-black dark:text-white">{{ $groupedResponses['emodul']['responses']['count'] ?? '0' }}</p>

                                <div class="text-white mt-2 text-center flex flex-row items-center justify-center rounded bg-gradient-to-r from-blue-500 to-cyan-500 w-[90%] h-fit">
                                    <div class="py-2 text-center flex items-center justify-center flex-col rounded w-full h-full">
                                        <p class="xl:text-xl">
                                            Pre-Test
                                        </p>
                                        <p class="xl:text-2xl">{{ $groupedResponses['emodul']['responses']['pre-test']['count'] ?? '0' }}</p>

                                        <div class="py-1 px-2 text-black mt-2 flex flex-col items-center justify-center rounded bg-white w-[90%] h-fit">
                                            <table class="text-sm text-start w-full">
                                                <tr>
                                                    <td>email</td>
                                                    <td>{{ $groupedResponses['emodul']['responses']['pre-test']['email'] ?? '0' }}</td>
                                                </tr>
                                                <tr>
                                                    <td>no-email</td>
                                                    <td>{{ $groupedResponses['emodul']['responses']['pre-test']['no-email'] ?? '0' }}</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="py-2 text-center flex items-center justify-center flex-col rounded w-full h-full">
                                        <p class="xl:text-xl">
                                            Post-Test
                                        </p>
                                        <p class="xl:text-2xl">{{ $groupedResponses['emodul']['responses']['post-test']['count'] ?? '0' }}</p>
                                        <div class="py-1 px-2 text-black mt-2 flex flex-col items-center justify-center rounded bg-white w-[90%] h-fit">
                                            <table class="text-sm text-start w-full">
                                                <tr>
                                                    <td>email</td>
                                                    <td>{{ $groupedResponses['emodul']['responses']['post-test']['email'] ?? '0' }}</td>
                                                </tr>
                                                <tr>
                                                    <td>no-email</td>
                                                    <td>{{ $groupedResponses['emodul']['responses']['post-test']['no-email'] ?? '0' }}</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ----------------------------- SCORING PERSONAL ------------------------------------- -->
            <div class="px-4 h-fit">
                <div class="flex lg:flex-nowrap flex-wrap md:gap-3 gap-10 m-4 mb-12">
                    <div class="flex w-full h-fit items-center justify-start flex-col rounded-md bg-gray-50 dark:bg-gray-800 shadow-md">
                        <div class="text-center rounded bg-teal-400 w-full p-4">
                            <p class="lg:text-3xl font-bold text-white">
                                SCORING
                            </p>
                        </div>

                        <div class="w-full h-fit flex justify-end items-end px-3 pt-2">
                            <a data-popover-target="popover-download-excel-scoring-{{ $selectedForm ?? $defaultSelectedForm }}" wire:click="exportExcel('scoring',0)" class="p-1 bg-green-500 text-white rounded hover:bg-green-600">
                                <svg class="w-5 h-5 text-white dark:text-white" aria-hidden="true" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 13V4M7 14H5a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1h-2m-1-5-4 5-4-5m9 8h.01"/>
                                </svg>           
                            </a>
                        </div>
                        <div data-popover id="popover-download-excel-scoring-{{ $selectedForm ?? $defaultSelectedForm }}" role="tooltip" 
                            class="absolute z-10 invisible inline-block text-sm transition-opacity duration-300  border rounded-lg 
                            shadow-xs opacity-0 text-gray-400 dark:text-white border-gray-600 dark:border-gray-200 bg-gray-800 dark:bg-gray-600">
                            <div class="py-2 px-3">
                                <p>Download</p>
                            </div>
                            <div data-popper-arrow></div>
                        </div>

                        <div class="flex flex-col xl:flex-nowrap flex-wrap items-start justify-center w-full h-full">
                            @php
                                $index = 0;
                                $indexNoEmail = 0;
                            @endphp
                            
                            <div class="flex flex-wrap gap-2 w-full px-3 pb-3">
                                
                                @foreach ($groupedAllResponsesScoring as $emailScoring => $categoryScoring)
                                    @php
                                        $index++;
                                        if(Str::startsWith($emailScoring, 'uuid:')){
                                            $indexNoEmail++;
                                        }
                                       
                                        $safeEmail = Str::slug($emailScoring); 

                                    @endphp
                                
                                    <div class="flex-[1_1_calc(50%-0.5rem)] items-center justify-center flex-col rounded bg-gray-200 dark:bg-gray-700 w-full px-2 py-1 mt-3 {{ $index > 2 && !$showAllScoring ? 'hidden' : '' }}">
                                        <h1 class="flex justify-between items-center mt-2 font-bold text-white bg-gradient-to-r from-blue-500 to-cyan-500 p-3 rounded shadow-md break-all lg:text-lg">{{ Str::startsWith($emailScoring, 'uuid:') ? 'No Email '.$indexNoEmail : $emailScoring }}
                                            <div class="h-fit flex justify-center items-center">
                                                <a data-popover-target="popover-download-excel-scoring-{{ $safeEmail}}" wire:click="exportExcel('scoringPersonal', @js($emailScoring))" class="p-1 bg-green-500 text-white rounded hover:bg-green-600">
                                                    <svg class="w-5 h-5 text-white" aria-hidden="true" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 13V4M7 14H5a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1h-2m-1-5-4 5-4-5m9 8h.01"/>
                                                    </svg>           
                                                </a>
                                            </div>
                                            <div data-popover id="popover-download-excel-scoring-{{ $safeEmail }}" role="tooltip" class="absolute z-10 invisible inline-block text-sm dark:text-white text-gray-400 transition-opacity duration-300 dark:bg-gray-600 border dark:border-gray-200 rounded-lg shadow-xs opacity-0  border-gray-600 bg-gray-800">
                                                <div class="py-2 px-3">
                                                    <p>Download</p>
                                                </div>
                                                <div data-popper-arrow></div>
                                            </div>
                                        </h1>
                                        @foreach ($categoryScoring as $categoryNameScoring => $formIdScoring)
                                            
                                            @php
                                                $categoryPrefix = \Illuminate\Support\Str::before($categoryNameScoring, '-');
                                                $dataRekap = collect();
                                            @endphp
                                            <div class="pt-3 px-2">
                                                <button type="button" 
                                                    id="toggleDetailScoring-{{ $safeEmail }}-{{ $formIdScoring->first()['form_id'] }}" 
                                                    class="toggle-detail-btn text-white dark:bg-blue-700 dark:hover:bg-blue-800 focus:ring-4 dark:focus:ring-blue-300 
                                                    font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 bg-blue-600 hover:bg-blue-700 
                                                    focus:outline-none focus:ring-blue-800"
                                                    data-email="{{ $safeEmail }}" 
                                                    data-category="{{ $formIdScoring->first()['form_id'] }}"

                                                    >Show Detail</button>
                                            </div>
                                            <div class="flex-[1_1_calc(50%-0.5rem)] rounded w-full px-3 pb-2 mt-3 hidden" id="detail-{{ $safeEmail }}-{{ $formIdScoring->first()['form_id'] }}">
                                                <h1 class="text-xl mt-2 text-center font-bold text-white bg-gradient-to-r dark:from-blue-600 dark:to-slate-700 p-2 from-gray-500 to-gray-700 rounded shadow-md">{{ $categoryNameScoring }}</h1>
                                                <div class="dark:bg-slate-600 bg-slate-300 flex-[1_1_calc(50%-0.5rem)] items-center justify-center flex-col rounded ">
                                                    
                                                    @foreach($formIdScoring as $dataFormScoring)                                             
                
                                                        <div class="flex-[1_1_calc(50%-0.5rem)] items-center justify-center flex-col rounded dark:bg-gray-800 w-full px-3 py-1">
                                                            <div class="bg-cyan-500 rounded mt-4 text-center overflow-hidden flex flex-col justify-center items-center w-full">
                                                                <p class="text-sm text-gray-400 p-0 bg-gray-200 w-1/4 rounded-b-2xl">Nama Form</p>
                                                                <h1 class="text-xl pt-0 pb-1 font-bold text-white">{{ $dataFormScoring['form_name'] }}</h1>
                                                            </div>
                                                            <div class="w-full rounded-md overflow-x-auto ">
                                                                <table class="w-full table-auto text-sm text-left rtl:text-right bg-white dark:text-gray-200 text-black dark:bg-slate-800 shadow-md rounded border-2">
                                                                    <thead class="uppercase text-black bg-slate-300">
                                                                        <tr class="text-center">
                                                                            <th class="sticky left-0 bg-slate-100 z-10 p-2 w-[150px] md:w-[220px]" >Pertanyaan</th>
                                                                            @foreach($dataFormScoring['items']->first()['attempts'] as $attempt => $items)
                                                                                <th class="p-3 text-center sticky bg-slate-200 left-0 w-[150px] md:w-[220px]">Attempt-{{ $attempt }}</th>
                                                                            @endforeach
                                                                        </tr>
                                                                    </thead>

                                                                    <tbody>                                                                        
                                                                        @foreach ($dataFormScoring['items'] as $questionScoring => $responsesDataScoring)
                                                                        
                                                                            <tr class="border-b-2 border-gray-400 text-start">
                                                                                <td class="p-3 sticky left-0 z-10 dark:bg-slate-700 bg-slate-300">
                                                                                    <div>   
                                                                                        <span>{{ Str::limit($responsesDataScoring['question'], 20) }}</span>
                                                                                        @if($responsesDataScoring['questionImage'])
                                                                                            
                                                                                            @php 
                                                                                                // Buat ID unik agar popover tidak tertukar antar baris
                                                                                                $imageId = 'sp-'. Str::slug($responsesDataScoring['questionImage']) . $responsesDataScoring['id'] . $loop->index;
                                                                                            @endphp
    
                                                                                            <img data-popover-target="popover-q-{{ $imageId }}" 
                                                                                                src="{{ $responsesDataScoring['questionImage'] }}" 
                                                                                                class="w-8 h-8 rounded-md object-cover cursor-pointer border border-gray-200 hover:scale-110 transition-transform"
                                                                                                alt="Preview">                                                                                            
                                                                                        @endif
                                                                                    </div>
                                                                                </td>
                                                                                @if($responsesDataScoring['questionImage'])
                                                                                    <div data-popover id="popover-q-{{ $imageId }}" role="tooltip" 
                                                                                        class="absolute z-50 invisible inline-block w-64 text-sm dark:text-gray-500 transition-opacity duration-300 dark:bg-white border dark:border-gray-200 rounded-lg shadow-sm opacity-0 text-gray-400 border-gray-600 bg-gray-800">
                                                                                        <div class="p-2">
                                                                                            <img src="{{ $responsesDataScoring['questionImage'] }}" 
                                                                                                class="w-full h-auto rounded-lg" alt="Full Preview">
                                                                                        </div>
                                                                                        <div data-popper-arrow></div>
                                                                                    </div>
                                                                                @endif
                                                                                @foreach($responsesDataScoring['attempts'] as $attemptScoring => $attemptDataScoring)
                                                                                    @foreach ($attemptDataScoring as $answerDataScoring)                                                                                     
                                                                                        <td>
                                                                                             <div class="flex items-center justify-center gap-2 flex-col">
                                                                                                <span><b>{{ $answerDataScoring->answer }}</b></span>
                                                                                                <div class="flex">
                                                                                                    @if($answerDataScoring->answerImage)
                                                                                                        @php 
                                                                                                            // Buat ID unik agar popover tidak tertukar antar baris
                                                                                                            $imageId = 'sp-' . Str::slug($answerDataScoring->answerImage) . $answerDataScoring->id . $loop->index;
                                                                                                        @endphp
        
                                                                                                        <img data-popover-target="popover-a-{{ $imageId }}" 
                                                                                                            src="{{ $answerDataScoring->answerImage }}" 
                                                                                                            class="w-8 h-8 rounded-md object-cover cursor-pointer border border-gray-200 hover:scale-110 transition-transform"
                                                                                                            alt="Preview">
        
                                                                                                        <div data-popover id="popover-a-{{ $imageId }}" role="tooltip" 
                                                                                                            class="absolute z-50 invisible inline-block w-64 text-sm dark:text-gray-500 transition-opacity duration-300 dark:bg-white border dark:border-gray-200 rounded-lg shadow-sm opacity-0 text-gray-400 border-gray-600 bg-gray-800">
                                                                                                            <div class="p-2">
                                                                                                                <img src="{{ $answerDataScoring->answerImage }}" 
                                                                                                                    class="w-full h-auto rounded-lg" alt="Full Preview">
                                                                                                            </div>
                                                                                                            <div data-popper-arrow></div>
                                                                                                        </div>
                                                                                                    @endif
                                                                                                    <span>({{ $answerDataScoring->value }})</span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </td>                                                                                        
                                                                                    @endforeach
                                                                                @endforeach
                                                                            </tr>
                                                                        @endforeach
                                                                        
                                                                        <tr class="bg-gray-400 text-white font-bold">
                                                                            <td class="p-3 text-start sticky left-0 z-10 bg-slate-500">Total</td>
                                                                            @foreach($dataFormScoring['total_score'] as $scoring)
                                                                            
                                                                                <td class="text-center">
                                                                                    <span>{{ $scoring }}</span>
                                                                                </td>
                                                                                
                                                                            @endforeach
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                    
                                                </div>
                                            </div>
                                            <div class="flex gap-2 flex-row xl:flex-nowrap flex-wrap items-start justify-center w-full bg-white p-3 rounded shadow-sm mt-2">
                                                @foreach($formIdScoring as $formScoring)
                                                    <div class="flex-[1_1_calc(50%-0.5rem)] items-center justify-center border-e-2">
                                                        
                                                        <h3 class="font-bold">{{ $formScoring['form_name'] }}</h3>
                                                        
                                                            @foreach($formScoring['total_score'] as $attempt => $score)
                                                                <div class="pt-2">
                                                                    
                                                                    @php
                                                                        $valueScoreRekap = 0;
                                                                        if($formScoring['max_score'] == 0){
                                                                            $valueScoreRekap = $score;
                                                                        }else{
                                                                            $valueScoreRekap = round(($score / $formScoring['max_score'] )*100);
                                                                        }

                                                                        if($valueScoreRekap == 0){
                                                                            $valueScoreRekap =2;
                                                                        }

                                                                        if($valueScoreRekap > 70){
                                                                            $bgBar="bg-green-300";
                                                                        }elseif($valueScoreRekap > 40){
                                                                            $bgBar="bg-yellow-300";
                                                                        }elseif($valueScoreRekap > 0){
                                                                            $bgBar="bg-red-300";
                                                                        }
                                                                    @endphp
                                                                    <p>Percobaan {{ $attempt }}</p>
                                                                    <div class="w-full border border-gray-500">
                                                                        <p class="{{ $bgBar }} px-2" style="width: {{ $valueScoreRekap }}%;">{{ $score . '/' . $formScoring['max_score'] }}</p>
                                                                    </div>
                                                                </div>
                                                            @endforeach
                                                    </div>
                                                @endforeach
                                            </div>  
                                        @endforeach
                                    </div>
                                @endforeach
                            </div>

                            <div class="text-center mt-4 w-full">
                                <hr class="mb-4">
                                <button wire:click="toggleShowAllScoring()" wire:loading.attr="disabled" id="toggle-scoring-btn" class="text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 rounded-lg text-sm px-5 py-2.5 me-2 mb-2 rounded-pill shadow-sm font-semibold">
                                    <svg class="inline w-6 h-6 text-gray-800" aria-hidden="true" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17h6l3 3v-3h2V9h-2M4 4h11v8H9l-3 3v-3H4V4Z"/>
                                    </svg>                                      
                                    <span id="see-all-txt">{{ $showAllScoring ? 'Sembunyikan Sebagian' : 'Tampilkan Semua' }}</span>
                                </button>
                            </div>
                             
                        </div>
                    </div>
                </div>
            </div>

            <!-- ----------------------------- SINGLE FORM DISPLAY ---------------------------------- -->
            <div class="flex items-center justify-center flex-col gap-3 rounded bg-slate-200 dark:bg-gray-600 py-10 px-4">
                <div class="relative overflow-hidden sm:rounded-lg w-full shadow-md dark:bg-slate-800 bg-white">
                    <h1 class="text-3xl font-bold bg-cyan-600 rounded p-3 mb-1 text-center text-white">Response Terekam</h1>
                    <div class="m-4">
                        <div class="m-4 flex flex-wrap justify-center gap-2">
                            <div class="flex-[1_1_calc(50%-0.5rem)] min-w-fit bg-slate-200 rounded p-3 border-2 border-gray-400 border-dashed">
                                <label for="countries" class="block mb-2 text-sm font-medium text-gray-900">Pilih Placement</label>
                                <select wire:model="selectedPlacement" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                                    <option value=''>Pilih Placement</option>
                                    <option value="pre-test-website">Pre-Test Website</option>
                                    <option value="post-test-website">Post-Test Website</option>
                                    <option value="pre-test-emodul">Pre-Test Emodul</option>
                                    <option value="post-test-emodul">Post-Test Emodul</option>
                                </select>
                            </div>
                            <div class="flex-[1_1_calc(50%-0.5rem)] bg-slate-200 rounded p-3 border-2 border-gray-400 border-dashed">
                                <label for="countries" class="block mb-2 text-sm font-medium text-gray-900">Pilih Judul Form</label>
                                <select wire:model="selectedForm" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                                    <option class="text-gray-300" value=''>-- Pilih Judul Form --</option>
                                    @if ($forms)
                                        @foreach ($forms as $form => $value)
                                    
                                            <option value="{{ $value }}">{{ $form }}</option>
                                        @endforeach
                                    @else
                                        <option value="0" disabled>-- no form available --</option>
                                    @endif
                                </select>
                            </div>
                        </div>
                        <button type="button" wire:click="loadData" class="text-white w-full bg-green-500 box-border border border-transparent hover:bg-green-600 focus:ring-4 focus:ring-green-300 shadow-xs font-medium leading-5 rounded text-sm px-4 py-2.5 focus:outline-none">Search</button>
                    </div>
                    
                    @if($responseData == null)
                        <div class="bg-blue-200 rounded  m-2 text-center shadow-md overflow-hidden flex flex-col justify-center items-center">
                            <p class="text-sm text-gray-400 p-1 bg-gray-200 w-1/4 rounded-b-2xl">Nama Form</p>
                            <h1 class="p-3 ">-- Belum ada response --</h1>
                        </div>
                    @else
                        
                        <div class="w-full h-fit p-2 flex justify-end items-end">
                            
                            <a data-popover-target="popover-download-response" wire:click="exportExcel('response',{{ $responseData->form_id }})" class="p-1 bg-green-500 text-white rounded hover:bg-green-600">
                                <svg class="w-6 h-6 text-white" aria-hidden="true" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 13V4M7 14H5a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1h-2m-1-5-4 5-4-5m9 8h.01"/>
                                </svg>           
                            </a>
                            <div data-popover id="popover-download-response" role="tooltip" class="absolute z-10 invisible inline-block text-sm dark:text-white transition-opacity duration-300 dark:bg-gray-600 border dark:border-gray-200 rounded-lg shadow-xs opacity-0 text-gray-400 border-gray-600 bg-gray-800">
                                <div class="py-2 px-3">
                                    <p>Download Response</p>
                                </div>
                                <div data-popper-arrow></div>
                            </div>
                        </div>

                        <div class=" rounded my-2 mx-3 p-1 text-center overflow-hidden flex flex-col justify-center items-center">
                            <div class="w-full rounded bg-cyan-500 flex flex-col justify-center items-center">
                                <p class="text-sm text-gray-400 px-4 py-1 bg-slate-200 w-fit rounded-b-2xl">Nama Form</p>
                                <h1 class="text-2xl pt-1 pb-2 font-bold text-white">{{ $responseData->form_name }}</h1>
                                
                            </div>
                            <div class="w-full h-fit p-2 flex justify-end items-end gap-3">
                            </div>
                            <div class="w-full overflow-x-auto rounded-md">
                                <table class="w-full table-auto text-sm rtl:text-right bg-white dark:bg-slate-600 dark:text-white text-black shadow-md rounded-md mb-2">
                                    <thead class="text-black uppercase bg-slate-300 rounded-md">
                                        <tr>
                                            <th class="sticky left-0 bg-slate-100 z-10 p-2 w-[150px] md:w-[220px]">Pertanyaan</th>
                                           @foreach ($columns as $col)
                                                <th class="sticky bg-slate-200 left-0 p-2" style="min-width:100px">
                                                    @if($col['email'])
                                                        <div class="flex justify-center items-center flex-col">
                                                            <div class="text-xs text-center break-all md:w-[100px] w-[50px]">{{ Str::limit($col['email'], 25) }}</div>
                                                            
                                                            <div class="text-gray-600" style="font-size:10px;">(Attempt {{ $col['attempt'] }})</div>
                                                        </div>
                                                       
                                                    @else
                                                        <div class="text-sm">NoEmail</div>
                                                        <div style="font-size:10px;">({{ date('y-m-d H:i', strtotime($col['created_at'])); }})</div>
                                                    @endif
                                                    
                                                </th>
                                            @endforeach
                                            
                                        </tr>
                                    </thead>
                                    <tbody class="rounded-md">
                                        @forelse ($groupedResponsesForSingleForm as $questionId => $responses)
                                            <tr x-data="{ open: false, pos: { x: 0, y: 0 } }">
                                                @php $question = $responses->first(); @endphp
                                                              
                                                <td class="sticky left-0 p-2 dark:bg-slate-700 bg-slate-200 z-10 border-b dark:border-gray-300 border-white text-start">
                                                    <p>{{ Str::limit($question->question, 20) }}</p>

                                                    @if($question->questionImage)
                                                        <img 
                                                            {{-- Saat mouse masuk, ambil koordinat gambar di layar --}}
                                                            @mouseenter="
                                                                open = true; 
                                                                let rect = $el.getBoundingClientRect(); 
                                                                pos.x = rect.left + (rect.width / 2); 
                                                                pos.y = rect.top;
                                                            " 
                                                            @mouseleave="open = false"
                                                            src="{{ $question->questionImage }}" 
                                                            class="w-8 h-8 rounded-md object-cover cursor-pointer border border-gray-200 hover:scale-110 transition-transform"
                                                            alt="Preview">
                                                    @endif
                                                </td>
                                                
                                                @if($question->questionImage)
                                                    <template x-teleport="body">
                                                        <div 
                                                            x-show="open" 
                                                            x-cloak
                                                            x-transition
                                                            {{-- Gunakan position fixed agar bebas dari overflow tabel --}}
                                                            class="fixed z-[999] w-64 p-2 dark:bg-white border dark:border-gray-200 rounded-lg shadow-xl bg-gray-800 border-gray-600 pointer-events-none"
                                                            {{-- Atur posisi berdasarkan koordinat gambar yang di-hover --}}
                                                            :style="`left: ${pos.x}px; top: ${pos.y}px; transform: translate(-50%, -110%);`"
                                                        >
                                                            <div class="relative">
                                                                <img src="{{ $question->questionImage }}" class="w-full h-auto rounded-lg" alt="Full Preview">
                                                                {{-- Arrow --}}
                                                                <div class="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 dark:bg-white bg-gray-800 border-r border-b dark:border-gray-200 border-gray-600 rotate-45"></div>
                                                            </div>
                                                        </div>
                                                    </template>
                                                @endif
                                            @foreach ($columns as $col)
                                                 
                                                @php 
                                                    $cellResponses = $cellMatrix[$questionId][$col['key']] ?? collect();
                                                @endphp
                                                             
                                                <td class="p-3 border-b border-gray-300" x-data="{ open: false }">
                                                    @foreach ($cellResponses as $r)    
                                                        {{-- Tambahkan x-data di level pembungkus jawaban --}}
                                                        <div x-data="{ open: false, pos: { x: 0, y: 0 } }" class="flex justify-center items-center flex-col relative">
                                                            <span>{{ Str::limit($r->answer, 20) }}</span>

                                                            @if($r->answerImage)                    
                                                                <img src="{{ $r->answerImage }}" 
                                                                    @mouseenter="
                                                                        open = true; 
                                                                        let rect = $el.getBoundingClientRect(); 
                                                                        pos.x = rect.left + (rect.width / 2); 
                                                                        pos.y = rect.top;
                                                                    " 
                                                                    @mouseleave="open = false"
                                                                    class="w-8 h-8 rounded-md object-cover cursor-pointer border border-gray-500 hover:scale-110 transition-transform"
                                                                    alt="Preview">

                                                                {{-- TELEPORT KE BODY AGAR TIDAK TERPOTONG TABEL --}}
                                                                <template x-teleport="body">
                                                                    <div x-show="open" 
                                                                        x-cloak
                                                                        x-transition
                                                                        class="fixed z-[999] w-64 p-2 dark:bg-white border dark:border-gray-200 rounded-lg shadow-xl bg-gray-800 border-gray-600 pointer-events-none"
                                                                        :style="`left: ${pos.x}px; top: ${pos.y}px; transform: translate(-50%, -110%);`"
                                                                    >
                                                                        <div class="relative">
                                                                            <img src="{{ $r->answerImage }}" 
                                                                                class="w-full h-auto rounded-lg shadow-sm" alt="Full Preview">
                                                                            
                                                                            {{-- Arrow --}}
                                                                            <div class="absolute -bottom-2 left-1/2 -translate-x-1/2 w-3 h-3 dark:bg-white bg-gray-800 border-r border-b dark:border-gray-200 border-gray-600 rotate-45"></div>
                                                                        </div>
                                                                    </div>
                                                                </template>
                                                            @endif
                                                        </div>                                       
                                                    @endforeach
                                                </td>
                                                @if($r->answerImage)
                                                    <template x-teleport="body">
                                                        <div 
                                                            x-show="open" 
                                                            x-cloak
                                                            x-transition
                                                            {{-- Gunakan position fixed agar bebas dari overflow tabel --}}
                                                            class="fixed z-[999] w-64 p-2 dark:bg-white border dark:border-gray-200 rounded-lg shadow-xl bg-gray-800 border-gray-600 pointer-events-none"
                                                            {{-- Atur posisi berdasarkan koordinat gambar yang di-hover --}}
                                                            :style="`left: ${pos.x}px; top: ${pos.y}px; transform: translate(-50%, -110%);`"
                                                        >
                                                            <div class="relative">
                                                                <img src="{{ $r->answerImage }}" class="w-full h-auto rounded-lg" alt="Full Preview">
                                                                {{-- Arrow --}}
                                                                <div class="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 dark:bg-white bg-gray-800 border-r border-b dark:border-gray-200 border-gray-600 rotate-45"></div>
                                                            </div>
                                                        </div>
                                                    </template>
                                                @endif
                                            @endforeach
                                        </tr>
                                        
                                        @empty
                                        <tr>
                                            <td colspan="{{ $columns->count() + 1 }}" class="p-4 text-center text-gray-500">
                                                -- Belum ada response --
                                            </td>
                                        </tr>
                                        @endforelse
                                        
                                    </tbody>
                                </table>
                                
                            </div>
                        </div>
                    @endif
                </div>
            </div>
            
            <!-- ----------------------------- REKAP JAWABAN FORM ---------------------------------- -->
            <div class="flex items-center justify-center flex-col gap-3 rounded dark:bg-slate-700 bg-slate-300 py-10 p-4">
                <div class="rounded mt-4 overflow-hidden w-full text-center shadow-md bg-white dark:bg-gray-900">
                    <h1 class="text-3xl font-bold p-3 bg-cyan-600 text-white">Rekap Jawaban</h1>
                    
                    @if (empty($rekapScoring))
                        <div class="bg-white rounded my-2 text-center overflow-hidden flex flex-col justify-center items-center">
                            <p class="text-sm text-gray-400 p-1 bg-gray-200 w-1/4 rounded-b-2xl">Nama Form</p>
                            <h1 class="pt-1 pb-2 text-gray-400">-- Belum ada response --</h1>
                        </div>
                    @else
                        <div class="w-full h-fit p-2 flex justify-end items-end">
                            <a data-popover-target="popover-download-excel-rekap" wire:click="exportExcel('rekap',0)" class="p-1 bg-green-500 text-white rounded hover:bg-green-600">
                                <svg class="w-6 h-6 text-white" aria-hidden="true" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 13V4M7 14H5a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1h-2m-1-5-4 5-4-5m9 8h.01"/>
                                </svg>           
                            </a>
                            <div data-popover id="popover-download-excel-rekap" role="tooltip" class="absolute z-10 invisible inline-block text-sm dark:text-white transition-opacity duration-300 dark:bg-gray-600 border dark:border-gray-200 rounded-lg shadow-xs opacity-0 text-gray-400 border-gray-600 bg-gray-800">
                                <div class="py-2 px-3">
                                    <p>Download Response Rekap</p>
                                </div>
                                <div data-popper-arrow></div>
                            </div>
                        </div>
                        
                        <div class="flex flex-wrap w-full gap-2 px-3 pb-3">
                            @foreach ($rekapScoring as $formName => $data)
                           
                                <div class="bg-cyan-500 rounded mt-4 text-center overflow-hidden flex flex-col justify-center items-center w-full">
                                    <p class="text-sm text-gray-400 p-0 bg-gray-200 w-1/4 rounded-b-2xl">Nama Form</p>
                                    <h1 class="text-xl pt-0 pb-1 font-bold text-white">{{ $formName }}</h1>
                                </div>
                                @php
                                    $popoverList=[];
                                @endphp
                                <div class="max-h-[500px] w-full overflow-auto relative rounded shadow-md">
                                    <table class="w-full text-sm bg-slate-50 dark:bg-slate-600 dark:text-white text-black">
                                        <thead class="uppercase bg-slate-300">
                                            <tr class="text-center sticky top-0 z-10 dark:bg-slate-400 bg-slate-200">
                                                <th class="p-3 min-w-[100px]">
                                                    Pertanyaan
                                                </th>
                                                
                                                @foreach ($data['answers'] as $answer)
                                                    <th class="p-3">
                                                        <div class="flex justify-center items-center">
                                                            <span class="normal-case">{{ $answer['answer'] }}</span>
                                                            @if($answer['answerImage'])
                                                                        
                                                                @php 
                                                                    $imageId = 'a-rs'. Str::slug($answer['answerImage']) . $answer['id'];
                                                                    // Simpan data ke array untuk dirender nanti
                                                                    $popoverList[] = [
                                                                        'id' => $imageId,
                                                                        'imageUrl' => $answer['answerImage']
                                                                    ];
                                                                @endphp
                                                                <img data-popover-target="popover-{{ $imageId }}" 
                                                                    src="{{ $answer['answerImage'] }}" 
                                                                    class="w-8 h-8 rounded-md object-cover cursor-pointer border border-gray-200 hover:scale-110 transition-transform"
                                                                    alt="Preview">
                                                            @endif

                                                        </div>
                                                    </th>
                                                @endforeach
                                            </tr>
                                        </thead>

                                        <tbody>
                                            @foreach ($data['rows'] as $row)
                                                
                                                <tr class="border-b border-gray-500 text-center">
                                                    <td class="p-3 text-left align-top">
                                                        {{ Str::limit($row['question'], 40) }}
                                                        @if($row['questionImage'])
                                                                               
                                                            @php 
                                                                // Buat ID unik agar popover tidak tertukar antar baris
                                                                $imageId = 'q-rs'. Str::slug($row['questionImage']) . $row['id'];
                                                                $popoverList[] = [
                                                                    'id' => $imageId,
                                                                    'imageUrl' => $row['questionImage']
                                                                ];
                                                            @endphp

                                                            <img data-popover-target="popover-{{ $imageId }}" 
                                                                src="{{ $row['questionImage'] }}" 
                                                                class="w-8 h-8 rounded-md object-cover cursor-pointer border border-gray-200 hover:scale-110 transition-transform"
                                                                alt="Preview">
                                                        @endif
                                                    </td>
                                                          
                                                    @foreach ($row['scores'] as $value)
                                                        <td class="p-3">
                                                            {{ $value }}
                                                        </td>
                                                    @endforeach
                                                </tr>
                                                 
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                @foreach($popoverList as $popover)
                                    <div data-popover id="popover-{{ $popover['id'] }}" role="tooltip" 
                                        class="absolute z-50 invisible inline-block w-64 text-sm dark:text-gray-500 transition-opacity duration-300 dark:bg-white border dark:border-gray-200 rounded-lg shadow-sm opacity-0 text-gray-400 border-gray-600 bg-gray-800">
                                        <div class="p-2">
                                            <img src="{{ $popover['imageUrl'] }}" 
                                                class="w-full h-auto rounded-lg" alt="Full Preview">
                                        </div>
                                        <div data-popper-arrow></div>
                                    </div>
                                    
                                @endforeach
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function toogleShowDetail(event) {
        // Ambil data langsung dari atribut data-
        const email = event.currentTarget.dataset.email;
        const category = event.currentTarget.dataset.category;
        
        // Update Text
        event.currentTarget.textContent = event.currentTarget.textContent.trim() === "Hidden Detail" 
            ? 'Show Detail' 
            : 'Hidden Detail';

        // Cari element detail menggunakan escape selector jika id mengandung @ atau .
        // Atau gunakan cara paling aman: document.getElementById
        const detailId = 'detail-' + email + '-' + category;
        const detail = document.getElementById(detailId);

        if (detail) {
            detail.classList.toggle('hidden');
        } else {
            console.error('Element tidak ditemukan:', detailId);
        }
    }

    // Inisialisasi event listener
    document.querySelectorAll('.toggle-detail-btn').forEach(btn => {
        btn.removeEventListener('click', toogleShowDetail);
        btn.addEventListener('click', toogleShowDetail);
    });
</script>