<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('forms', function (Blueprint $table) {
            $table->id();
            $table->string('form_name');
            $table->enum('placement', ['post-test-interkatif', 'pre-test-interkatif', 'post-test-emodul', 'pre-test-emodul','disable']);
            $table->boolean('collect_email')->default(true);
            $table->boolean('one_attempt')->default(false);
            $table->boolean('must_fill')->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('forms');
    }
};
