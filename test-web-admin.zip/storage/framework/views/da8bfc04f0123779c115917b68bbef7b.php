<script>
    webpageJs = <?php echo \Illuminate\Support\Js::from($webpage)->toHtml() ?>;
    paramJs = <?php echo \Illuminate\Support\Js::from($param)->toHtml() ?>;
</script>

<div id="webpage"></div>
<?php /**PATH C:\laragon\www\test-web-admin\resources\views/livewire/pageInteraktif/interaktif-page.blade.php ENDPATH**/ ?>