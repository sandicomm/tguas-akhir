<div class=" text-center text-white">
    <h1 class="text-4xl font-extrabold">ADMIN SMART HEALTH DIABETES</h1>
    <h2 class="text-lg">Admin Login</h2>
</div><?php /**PATH C:\laragon\www\test-web-admin\resources\views/components/application-logo.blade.php ENDPATH**/ ?>