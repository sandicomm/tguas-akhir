<table>
    <tr>
        <td colspan="2" style="font-weight: bold; font-size: 14px;">Detail Jawaban: <?php echo e($email); ?></td>
    </tr>
    <tr>
        <td colspan="2">Form: <?php echo e($forms->form_name); ?></td>
    </tr>
</table>

<?php
    // Grouping data berdasarkan attempt
    $groupedByAttempt = $responses->groupBy('attempt');
?>

<?php $__currentLoopData = $groupedByAttempt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    
    <table border="1" style="margin-top: 20px;">
        <thead>
            <tr>
                <th colspan="2" style="background-color: #f0f0f0; font-weight: bold;">
                    Percobaan Ke-<?php echo e($attempt); ?>

                </th>
            </tr>
            <tr>
                <th style="background-color: #cccccc; width: 400px;">Pertanyaan</th>
                <th style="background-color: #cccccc; width: 200px;">Jawaban (Nilai)</th>
            </tr>
        </thead>
        <tbody>
            <?php $totalScore = 0; ?>

            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($resp->answer->question->question ?? '-'); ?></td>
                    <td>
                        <?php echo e($resp->answer->answer ?? '-'); ?> 
                        <strong>(<?php echo e($resp->answer->value ?? 0); ?>)</strong>
                    </td>
                </tr>
                <?php 
                    // Pastikan value di-cast ke int agar aman hitungannya
                    $totalScore += (int) ($resp->answer->value ?? 0); 
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td style="text-align: right; font-weight: bold;">TOTAL SKOR</td>
                <td style="font-weight: bold;"><?php echo e($totalScore); ?></td>
            </tr>
        </tbody>
    </table>
    <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\laragon\www\test-web-admin\resources\views/exports/scoring.blade.php ENDPATH**/ ?>