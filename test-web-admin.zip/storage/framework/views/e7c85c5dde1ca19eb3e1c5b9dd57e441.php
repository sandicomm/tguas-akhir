<?php if (isset($component)) { $__componentOriginal66080d40165dc237152ede315c1d0309 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66080d40165dc237152ede315c1d0309 = $attributes; } ?>
<?php $component = App\View\Components\ErrorLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('error-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ErrorLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex flex-col items-center justify-center h-[100vh] bg-sky-950 text-center">
        <h1 class="font-bold text-7xl text-red-500">404</h1>
        <p class="text-xl mt-4 text-white">Maaf halaman yang anda cari tidak ditemukan.</p>
        <a href="<?php echo e(route('home')); ?>" 
        class="mt-4 border-2 focus:outline-none focus:ring-4 font-medium rounded-lg 
        text-sm px-5 py-2.5 me-2 mb-2 bg-gray-800 text-white border-gray-600 
        hover:bg-gray-700 hover:border-gray-600 focus:ring-gray-700">Kembali</a>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66080d40165dc237152ede315c1d0309)): ?>
<?php $attributes = $__attributesOriginal66080d40165dc237152ede315c1d0309; ?>
<?php unset($__attributesOriginal66080d40165dc237152ede315c1d0309); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66080d40165dc237152ede315c1d0309)): ?>
<?php $component = $__componentOriginal66080d40165dc237152ede315c1d0309; ?>
<?php unset($__componentOriginal66080d40165dc237152ede315c1d0309); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\test-web-admin\resources\views/errors/404.blade.php ENDPATH**/ ?>