<table>
    <thead>
        <tr>
            <th colspan="2" style="font-weight: bold; font-size: 16px;">LAPORAN DATA RESPONSE</th>
        </tr>
        <tr>
            <th colspan="2" style="font-weight: bold;">Form: <?php echo e($formName); ?></th>
        </tr>
    </thead>
</table>

<table border="1">
    <thead>
        <tr>
            <th style="background-color: #cccbca; font-weight: bold; width: 300px; text-align: center; vertical-align: middle;">
                PERTANYAAN
            </th>
            
            <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th style="background-color:#cccbca; font-weight: bold; width: 200px; text-align: center;">
                    <?php echo e($col['email'] != '' ?  strtoupper($col['email']) : 'No Email'); ?><br>
                    (ATTEMPT <?php echo e($col['attempt']); ?>)
                </th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="font-weight: 500;">
                    <?php echo e($question->question); ?>

                </td>

                <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $rowResponses = $cellMatrix[$question->id] ?? []; 
                        $cellResponses = $rowResponses[$col['key']] ?? collect();
                    ?>

                    <td style="text-align: center; vertical-align: middle;">
                        <?php $__empty_1 = true; $__currentLoopData = $cellResponses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>  
                            <?php echo e($r->answer, 20); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <span style="color: #d1d5db;">-</span>
                        <?php endif; ?>
                    </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laragon\www\test-web-admin\resources\views/exports/responses-single.blade.php ENDPATH**/ ?>