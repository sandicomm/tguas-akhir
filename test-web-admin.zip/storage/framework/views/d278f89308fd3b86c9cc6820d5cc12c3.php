<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="description" content="Smart Health Diabetes untuk edukasi dan pembelajaran Diabetes Melitus secara online.">
    <meta name="keywords" content="smart diabetes, smart health diabetes, kesehatan">
    <meta name="robots" content="index, follow">
    
    <!-- Open Graph -->
    <meta property="og:title" content="Smart Health Diabetes">
    <meta property="og:description" content="Platform pembelajaran diabetes online.">
    <meta property="og:url" content="https://smartdiabetes.my.id/">
    <meta property="og:type" content="website">
    
    <title><?php echo e($title ?? 'Prolog'); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('shdicon.ico')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js', 'resources/js/interaktifPage.js']); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body class="relative">
    <?php echo e($slot); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html><?php /**PATH C:\laragon\www\test-web-admin\resources\views/layouts/prolog.blade.php ENDPATH**/ ?>