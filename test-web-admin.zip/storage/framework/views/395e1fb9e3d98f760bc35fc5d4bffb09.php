<table>
    <thead>
        <tr>
            <th colspan="3" style="font-weight: bold; font-size: 14px;">LAPORAN SCORING PERSONAL</th>
        </tr>
        <tr>
            <th colspan="3" style="background-color: #4b5563; color: #ffffff; font-weight: bold; border: 1px solid #000000;">Email: <?php echo e($userKey); ?></th>
        </tr>
    </thead>
</table>

<?php
    $groupedByForm = $responses->groupBy(function($item) {
        return $item->answer->question->section->form->id;
    });
?>

<?php $__currentLoopData = $groupedByForm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formName => $formResponses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        // 2. Ambil data form dari item pertama dalam grup ini
        $firstResponse = $formResponses->first();
        $formObject = $firstResponse->answer->question->section->form;
        $formName = $formObject->form_name;
        $placement = $formObject->placement;
    ?>
    <div style="margin-bottom: 50px; page-break-after: always;">
        
        
        <table>
            <tr>
                <td colspan="3" style="background-color: #4b5563; color: #ffffff; font-weight: bold; border: 1px solid #000000;">
                    FORM: <?php echo e($formName); ?>

                </td>
            </tr>
            <tr>
                <td colspan="3" style="background-color: #4b5563; color: #ffffff; font-weight: bold; border: 1px solid #000000;">
                    PLACEMENT: <?php echo e($placement); ?>

                </td>
            </tr>
        </table>

        <?php
            // 2. Logika Matrix internal untuk Form ini saja
            $columns = $formResponses->map(function($item) {
                    return [
                        'attempt' => $item->attempt,
                        'col_key' => ($item->responden->email ?? 'Guest') . '-' . $item->attempt
                    ];
                })
                ->unique('col_key')
                ->sortBy(['attempt']);

            $questions = $formResponses->pluck('answer.question')
                ->unique('id')
                ->sortBy('order')
                ->values();

            $matrix = [];
            foreach ($formResponses as $resp) {
                $colKey = ($resp->responden->email ?? 'Guest') . '-' . $resp->attempt;
                $matrix[$resp->answer->question->id][$colKey] = [
                    'answer' => $resp->answer->answer,
                    'value' => (int) ($resp->answer->value ?? 0)
                ];
            }
        ?>

        
        <table border="1" style="border-collapse: collapse; width: 100%;">
            <thead>
                <tr>
                    <th style="background-color: #f3f4f6; font-weight: bold; width: 300px; padding: 8px;">
                        PERTANYAAN
                    </th>
                    <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th style="background-color: #e5e7eb; font-weight: bold; width: 100px; text-align: center;">
                            ATTEMPT <?php echo e($col['attempt']); ?>

                        </th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="background-color: #f9fafb; padding: 8px; font-size: 12px;">
                            <?php echo e($question->question); ?>

                        </td>

                        <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                                $dataCell = $matrix[$question->id][$col['col_key']] ?? null; 
                            ?>
                            <td style="text-align: center; vertical-align: middle; padding: 5px;">
                                <?php if($dataCell): ?>
                                    <span style="font-size: 11px;"><?php echo e($dataCell['answer']); ?></span><br>
                                    <strong style="font-size: 10px;">(<?php echo e($dataCell['value']); ?>)</strong>
                                <?php else: ?>
                                    <span style="color: #d1d5db;">-</span>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td style="background-color: #f3f4f6; font-weight: bold; text-align: right; padding: 8px;">TOTAL SCORING</td>
                    <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $currentColTotal = 0;
                            foreach ($questions as $q) {
                                $currentColTotal += $matrix[$q->id][$col['col_key']]['value'] ?? 0;
                            }
                        ?>
                        <td style="background-color: #fef08a; font-weight: bold; text-align: center;">
                            <?php echo e($currentColTotal); ?>

                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </tfoot>
        </table>
    </div>

    
    <hr style="border: 1px dashed #ccc; margin: 40px 0;">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\laragon\www\test-web-admin\resources\views/exports/single-form-scoring.blade.php ENDPATH**/ ?>