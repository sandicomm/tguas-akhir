
<?php
$classes = 'flex items-center p-2 text-gray-900 rounded-lg dark:text-white hover:bg-blue-500 group';
?>

<a <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\laragon\www\test-web-admin\resources\views/components/nav-link.blade.php ENDPATH**/ ?>