<div class="px-4 h-64 flex items-center justify-center">
    <div class="flex flex-col items-center gap-2">
        <div class="animate-spin rounded-full h-10 w-10 border-b-2 border-teal-500"></div>
        <p class="text-gray-500 italic">Menyinkronkan data responden...</p>
    </div>
</div><?php /**PATH C:\laragon\www\test-web-admin\storage\framework\views/61c507d52b52b40f874030c8c9a2db05.blade.php ENDPATH**/ ?>