<div>
    <div class="flex lg:flex-nowrap flex-wrap md:gap-3 gap-10 m-4 mb-12">
        <div class="flex w-full h-fit items-center justify-start flex-col rounded-md bg-gray-50 dark:bg-gray-800 shadow-md">
            <div class="text-center rounded bg-teal-400 w-full p-4">
                <p class="lg:text-3xl font-bold text-white">
                    SCORING
                </p>
            </div>

            <div class="flex flex-col xl:flex-nowrap flex-wrap items-start justify-center w-full h-full">
                <?php
                    $index = 0;
                    $indexNoEmail = 0;
                ?>
                <div class="w-full p-3 flex">
                    <div class="w-full bg-slate-300 p-3 rounded">
                        <label class="text-slate-800 font-bold">Pilih Form</label>
                        <select wire:model.live="selectedFormId" class="w-full bg-white text-black rounded px-3 py-2">
                            <option value="interaktif" >interaktif</option>
                            <option value="emodul">emodul</option>
                            <option value="disable">disable</option>
                            <option value="">all</option>
                        </select>
                 
                    </div>
                    <div class="flex justify-start items-start px-3 pt-2">
                        <a wire:click="exportAll" class="p-1 bg-green-500 text-white rounded hover:bg-green-600">
                            <svg class="w-5 h-5 text-white dark:text-white" aria-hidden="true" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 13V4M7 14H5a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1h-2m-1-5-4 5-4-5m9 8h.01"/>
                            </svg>           
                        </a>
                    </div>
                </div>
                
                <div class="flex flex-wrap gap-2 w-full px-3 pb-3 overflow-y-auto">
                    <div class="flex flex-wrap gap-2 w-full max-h-[90vh]">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->groupedAllResponsesScoring; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userKey => $forms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex-[1_1_calc(50%-0.5rem)] dark:bg-slate-600 bg-white p-4 rounded mb-4">
                                <div class="flex justify-between items-center">
                                    <h3 class="font-bold dark:text-white"><?php echo e($userKey); ?></h3>
                                    <div class="w-full h-fit flex justify-end items-end px-3 pt-2">
                                        <a wire:click="export( '<?php echo e($userKey); ?>' )" class="p-1 bg-green-500 text-white rounded hover:bg-green-600">
                                            <svg class="w-5 h-5 text-white dark:text-white" aria-hidden="true" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 13V4M7 14H5a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1h-2m-1-5-4 5-4-5m9 8h.01"/>
                                            </svg>           
                                        </a>
                                    </div>
                                </div>
                                
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formId => $formData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="border-t mt-2 pt-2 dark:text-white">
                                        <p><?php echo e($formData['form_name']); ?> (<?php echo e($formData['placement']); ?>)</p>
                                        <button 
                                            wire:click="openDetail('<?php echo e($userKey); ?>', '<?php echo e($formId); ?>')" 
                                            class="bg-blue-600 text-white px-1.5 py-1 rounded hover:bg-blue-400 mb-2 transition"
                                        >
                                            <small>Detail</small>
                                        </button>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $formData['attempts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attemptNo => $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="mb-2">
                                                <small>Percobaan <?php echo e($attemptNo); ?></small>
                                                <div class="w-full border border-gray-500">
                                                    
                                                    <?php 
                                                        $max = $this->scoreAnswer[$formId]->max_score ?? 100;
                                                        $percent = ($score / $max) * 100;

                                                        $valueScoreRekap = 0;
                                                        if($max == 0){
                                                            $valueScoreRekap = $score;
                                                        }else{
                                                            $valueScoreRekap = round(($score / $max )*100);
                                                        }

                                                        if($valueScoreRekap == 0){
                                                            $valueScoreRekap =2;
                                                        }

                                                        if($valueScoreRekap > 70){
                                                            $bgBar="bg-green-300";
                                                        }elseif($valueScoreRekap > 40){
                                                            $bgBar="bg-yellow-300";
                                                        }elseif($valueScoreRekap > 0){
                                                            $bgBar="bg-red-300";
                                                        }

                                                    ?>
                                                   
                                                    <div class="<?php echo e($bgBar); ?> text-black" style="width: <?php echo e($valueScoreRekap); ?>%"><?php echo e($score . '/' . $max); ?></div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!--[if BLOCK]><![endif]--><?php if($showModal): ?>
                        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50 overflow-y-auto">
                            <div class="dark:bg-slate-800 bg-slate-200 rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
                                
                                <div class="p-4 border-b border-slate-700 flex justify-between items-center bg-blue-600 text-white">
                                    <h2 class="text-lg font-bold"><?php echo e($selectedFormData['form_name']); ?> - <?php echo e($selectedFormData['user']); ?></h2>
                                    <button wire:click="closeModal" class="text-white hover:text-gray-200 text-2xl">&times;</button>
                                </div>

                                <div class="p-6 overflow-auto bg-slate-700">
                                    <table class="w-full border-collapse border border-gray-400 text-white">
                                        <thead class="bg-gray-200 text-black uppercase text-sm">
                                            <tr>
                                                <th class="border border-gray-400 p-2 text-left">PERTANYAAN</th>
                                         
                                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $availableAttempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $at): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                    <th class="border border-gray-400 p-2 text-center">ATTEMPT-<?php echo e($at); ?></th>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            </tr>
                                        </thead>
                                        <tbody class="text-sm">
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selectedFormData['questions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="border-b border-gray-400 hover:bg-gray-600 transition">
                                                    
                                                    <td class="border border-gray-400 p-2 font-medium bg-gray-800"><?php echo e(Str::limit($q[1]['question'],120)); ?></td>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $availableAttempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $at): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td class="border border-gray-400 p-2 text-center">
                                                            
                                                            <!--[if BLOCK]><![endif]--><?php if(isset($q[$at])): ?>
                                                                <div class="flex flex-col">
                                                                    <span><?php echo e(Str::limit($q[$at]['answer'],120)); ?></span>
                                                                    <span class="text-blue-300 font-bold">(<?php echo e($q[$at]['score']); ?>)</span>
                                                                </div>
                                                            <?php else: ?>
                                                                <span class="text-gray-500">-</span>
                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                        </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </tbody>
                                        <tfoot class="bg-gray-600 font-bold">
                                            <tr>
                                                <td class="border border-gray-400 p-2">Total</td>
                                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $availableAttempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $at): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        // Pastikan $at yang digunakan adalah nilai ID/Angkanya saja, bukan object model
                                                        $attemptKey = is_object($at) ? $at->attempt : $at;

                                                        $totalScore = collect($selectedFormData['questions'])->sum(function($q) use ($attemptKey) {
                                                            // Kita akses ke dalam nested array 'attempts'
                                                           
                                                            return $q[$attemptKey]['score'] ?? 0;
                                                        });
                                                    ?>
                                                    
                                                    <td class="border border-gray-400 p-2 text-center text-yellow-300 font-bold">
                                                        <?php echo e($totalScore); ?>

                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>

                                <div class="p-4 border-t border-slate-700 flex justify-end bg-slate-800">
                                    <button wire:click="closeModal" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600 transition">
                                        Tutup
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div wire:loading class="hidden" id='jsLoader'>
                    <?php if (isset($component)) { $__componentOriginal50c4b79f45ebbaf745fc521f681493a1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50c4b79f45ebbaf745fc521f681493a1 = $attributes; } ?>
<?php $component = App\View\Components\Loading::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Loading::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50c4b79f45ebbaf745fc521f681493a1)): ?>
<?php $attributes = $__attributesOriginal50c4b79f45ebbaf745fc521f681493a1; ?>
<?php unset($__attributesOriginal50c4b79f45ebbaf745fc521f681493a1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50c4b79f45ebbaf745fc521f681493a1)): ?>
<?php $component = $__componentOriginal50c4b79f45ebbaf745fc521f681493a1; ?>
<?php unset($__componentOriginal50c4b79f45ebbaf745fc521f681493a1); ?>
<?php endif; ?>
                </div>

                <div class="text-center mt-4 flex justify-center  p-3 w-full">
                    <hr class="mb-4">
                    <div class=" pagination-sm">
                        <?php echo e($this->groupedAllResponsesScoring->links()); ?>

                    </div>
                </div>
                    
            </div>
        </div>
    </div>
</div>
<script>
    document.addEventListener('livewire:navigated', () => { 
        initToggleButtons();
    });

    // Jalankan setiap kali Livewire selesai melakukan update DOM
    document.addEventListener('livewire:init', () => {
        Livewire.on('morph.updated', () => {
            initToggleButtons();
        });
    });

    function initToggleButtons() {
        console.log('Inisialisasi script detail...');
        document.querySelectorAll('.toggle-detail-btn').forEach(btn => {
            // Gunakan onclick langsung atau bersihkan listener lama
            btn.onclick = function(e) {
                const email = this.dataset.email;
                const category = this.dataset.category;
                const detailId = 'detail-' + email + '-' + category;
                const detail = document.getElementById(detailId);

                if (detail) {
                    detail.classList.toggle('hidden');
                    this.textContent = detail.classList.contains('hidden') ? 'Show Detail' : 'Hide Detail';
                }
            };
        });
    }

    // Panggil pertama kali
    initToggleButtons();
</script><?php /**PATH C:\laragon\www\test-web-admin\resources\views/livewire/dashboard/scoring-personal.blade.php ENDPATH**/ ?>