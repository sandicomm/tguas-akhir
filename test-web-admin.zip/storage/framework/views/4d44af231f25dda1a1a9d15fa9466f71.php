<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Error - <?php echo e(config('app.name')); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('shdicon.ico')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <!-- <link rel="stylesheet" href="<?php echo e(asset('build/assets/app.css')); ?>">
        <script type="module" src="<?php echo e(asset('build/assets/app.js')); ?>"></script> -->
</head>
<body class="bg-gray-100">
    <?php echo e($slot); ?>

</body>
</html><?php /**PATH C:\laragon\www\test-web-admin\resources\views/layouts/error.blade.php ENDPATH**/ ?>