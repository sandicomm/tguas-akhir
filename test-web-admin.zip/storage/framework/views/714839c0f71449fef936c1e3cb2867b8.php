<div>
    <div class="bg-white py-3 px-4 rounded w-100 flex justify-center align-center mb-2 text-xl">
        <h1><?php echo e($placement); ?></h1>
    </div>
    <?php
        $page = session('page_visited') ?? '';
    ?>
 
    <div class="box-soal w-100">  
        <!--[if BLOCK]><![endif]--><?php if($formMustFill == 0): ?>
            <div class="bg-white w-100 rounded p-4 flex justify-center align-center flex-col text-center mb-4">
                
                <!--[if BLOCK]><![endif]--><?php if($page == 'interaktif'): ?>
                    <a href="<?php echo e(route('interaktif')); ?>" class="bg-green-600 p-3 px-5 rounded font-bold text-white mt-4">Lanjutkan</a>
                <?php elseif($page == 'emodul'): ?>
                    <a href="<?php echo e(route('emodul')); ?>" class="bg-green-600 p-3 px-5 rounded font-bold text-white mt-4">Lanjutkan</a>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->       
        <form action="<?php echo e(route('cek-email.cek')); ?>" method="post" class="w-100 flex justify-center align-center flex-col gap-2">
            <?php echo csrf_field(); ?>
            <div class="bg-white w-100 rounded p-4 flex justify-center align-center flex-col">
                <label for="responden-email" class="text-center"><b>Email Anda <span class="text-red-600">*</span></b></label>
                <input type="hidden" name="placement" value="<?php echo e($placement); ?>">
                <input type="email" id="responden-email" class="text-center mt-3 <?php $__errorArgs = ['responden_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email Anda" name="responden_email" required>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['responden_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                <button type="submit" class="bg-green-600 p-4 px-5 rounded mt-4 font-bold text-white">Cek Email</button>
            </div>
        </form>
    </div>
</div><?php /**PATH C:\laragon\www\test-web-admin\resources\views/livewire/formTest/form-test-email.blade.php ENDPATH**/ ?>