<table>
    <thead>
        <tr>
            <th colspan="3" style="font-weight: bold; font-size: 16px;">SCORING FORM <?php echo e($placement); ?></th>
        </tr>
    </thead>
</table>

<?php $__currentLoopData = $groupedData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email => $forms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formId => $responses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
        <?php
            // === LOGIKA PEMROSESAN DATA PER FORM ===
            
            // 1. Ambil Meta Data Form (Cukup dari data pertama)
            $firstResponse = $responses->first();
            $formObject = $firstResponse->answer->question->section->form;
            $formName = $formObject->form_name;
            $placement = $formObject->placement;

            // 2. Identifikasi Attempt (Kolom) - Khusus untuk form ini saja
            $attempts = $responses->pluck('attempt')->unique()->sort()->values();
            
            // 3. Identifikasi Pertanyaan (Baris) - Khusus untuk form ini saja
            $questions = $responses->pluck('answer.question')
                ->unique('id')
                ->sortBy('order') // Pastikan ada kolom order/id agar urut
                ->values();

            // 4. Build Matrix [question_id][attempt]
            // Kita pakai array asosiatif agar aksesnya cepat dan tepat
            $matrix = [];
            foreach ($responses as $resp) {
                // Pastikan handle jika answer null (optional)
                $ans = $resp->answer;
                if ($ans) {
                    $matrix[$ans->question_id][$resp->attempt] = [
                        'answer' => $ans->answer,
                        'value'  => (int) ($ans->value ?? 0)
                    ];
                }
            }
            
            // Hitung total kolom untuk colspan header
            $totalColumns = $attempts->count() + 1; // +1 untuk kolom Pertanyaan
        ?>

        <table>
            <tr>
                <td colspan="<?php echo e($totalColumns); ?>" style="background-color: #4b5563; color: #ffffff; font-weight: bold; border: 1px solid #000000;">
                    RESPONDEN: <?php echo e($email); ?>

                </td>
            </tr>
            <tr>
                <td colspan="<?php echo e($totalColumns); ?>" style="background-color: #4b5563; color: #ffffff; font-weight: bold; border: 1px solid #000000;">
                    FORM: <?php echo e($formName); ?>

                </td>
            </tr>
            <tr>
                <td colspan="<?php echo e($totalColumns); ?>" style="background-color: #4b5563; color: #ffffff; font-weight: bold; border: 1px solid #000000;">
                    PLACEMENT: <?php echo e($placement); ?>

                </td>
            </tr>
        </table>

        <table border="1">
            <thead>
                <tr>
                    <th style="background-color: #f3f4f6; font-weight: bold; width: 350px; text-align: center; border: 1px solid #000000;">
                        PERTANYAAN
                    </th>
                    <?php $__currentLoopData = $attempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th style="background-color: #e5e7eb; font-weight: bold; width: 100px; text-align: center; border: 1px solid #000000;">
                            ATTEMPT <?php echo e($attempt); ?>

                        </th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="background-color: #f9fafb; border: 1px solid #000000;">
                            <?php echo e($question->question); ?>

                        </td>
                        
                        <?php $__currentLoopData = $attempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                                $cell = $matrix[$question->id][$attempt] ?? null; 
                            ?>
                            <td style="text-align: center; border: 1px solid #000000;">
                                <?php if($cell): ?>
                                    
                                    <?php echo e($cell['answer']); ?> <br>
                                    <span style="font-size: 10px; color: #555;">(Skor: <?php echo e($cell['value']); ?>)</span>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td style="background-color: #f3f4f6; font-weight: bold; text-align: right; border: 1px solid #000000;">
                        TOTAL SKOR
                    </td>
                    <?php $__currentLoopData = $attempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $attemptTotal = 0;
                            foreach ($questions as $q) {
                                $attemptTotal += $matrix[$q->id][$attempt]['value'] ?? 0;
                            }
                        ?>
                        <td style="background-color: #fef08a; font-weight: bold; text-align: center; border: 1px solid #000000;">
                            <?php echo e($attemptTotal); ?>

                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </tfoot>
        </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <table>
        <tr><td colspan="<?php echo e($totalColumns); ?>" style="height: 25px; background-color: #e31a00;"></td></tr>
    </table>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\laragon\www\test-web-admin\resources\views/exports/scoring-all-single.blade.php ENDPATH**/ ?>