<div class="relative w-[80%]">
    <?php
        $page = session('page_visited') ?? '';
    ?>
    <!--[if BLOCK]><![endif]--><?php if($form): ?>
        <div class="rounded mb-2 bg-white p-3 rounded-3 w-full flex justify-center items-center">
            <h1 class="font-bold text-3xl"><?php echo e($form->form_name); ?></h1>
        </div>
        
        <div class="w-full">
            <?php
                $formResponded = session('already_fill_form') ?? '';
                $alreadyFillTheForm = collect($formResponded)->contains($form->id);
            ?>
          
            <!--[if BLOCK]><![endif]--><?php if($form->one_attempt == 1 && $alreadyFillTheForm): ?>

                <div class="bg-white w-full rounded p-4 flex justify-center items-center flex-col">
                    <h5>Anda Sudah Mengerjakan Form Ini</h5>
                    
                    <!--[if BLOCK]><![endif]--><?php if($page == 'interaktif'): ?>
                        <a href="<?php echo e(route('interaktif')); ?>" class="bg-green-600 p-3 px-5 rounded font-bold text-white mt-4">Lanjutkan</a>
                    <?php elseif($page == 'emodul'): ?>
                        <a href="<?php echo e(route('emodul')); ?>" class="bg-green-600 p-3 px-5 rounded font-bold text-white mt-4">Lanjutkan</a>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
    
            <?php else: ?>
                
                <form action="<?php echo e(route('form-test.store')); ?>" method="post" class="w-full flex justify-center items-center flex-col gap-2">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="form_name" value="<?php echo e($form->form_name); ?>">
                    <input type="hidden" name="form_id" value="<?php echo e($form->id); ?>">
            
                    <!--[if BLOCK]><![endif]--><?php if($form->collect_email == 1): ?>
                        <input type="hidden" name="responden_email" value="<?php echo e(session('responden_email')); ?>">
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
                    <input type="hidden" name="collect_email" value="<?php echo e($form->collect_email); ?>">
                    <input type="hidden" name="one_attempt" value="<?php echo e($form->one_attempt); ?>">
                    <input type="hidden" name="placement" value="<?php echo e($form->placement); ?>">
    
                    <!--[if BLOCK]><![endif]--><?php if($form->collect_email == 1 && $form->must_fill == 0 && $alreadyFillTheForm): ?>
                        <div class="bg-white w-full rounded p-4 flex justify-center items-center flex-col text-center mb-4 gap-3">
                            <p><strong>Email anda sudah pernah digunakan untuk mengisi pre-test ini anda bisa langsung ke materi, atau mengisi pre-test lagi</strong></p>
                            <!--[if BLOCK]><![endif]--><?php if($page == 'interaktif'): ?>
                                <a href="<?php echo e(route('interaktif')); ?>" class="bg-green-600 p-3 px-5 rounded font-bold text-white mt-4">Lanjutkan</a>
                            <?php elseif($page == 'emodul'): ?>
                                <a href="<?php echo e(route('emodul')); ?>" class="bg-green-600 p-3 px-5 rounded font-bold text-white mt-4">Lanjutkan</a>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php elseif($form->must_fill == 0): ?>
                        <div class="bg-white w-full rounded p-4 flex justify-center items-center flex-col text-center mb-4">
                            <!--[if BLOCK]><![endif]--><?php if($page == 'interaktif'): ?>
                                <a href="<?php echo e(route('interaktif')); ?>" class="bg-green-600 p-3 px-5 rounded font-bold text-white mt-4">Lanjutkan</a>
                            <?php elseif($page == 'emodul'): ?>
                                <a href="<?php echo e(route('emodul')); ?>" class="bg-green-600 p-3 px-5 rounded font-bold text-white mt-4">Lanjutkan</a>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white rounded w-full p-4">
                            <input type="hidden" name="sections[<?php echo e($section->id); ?>][section]" value="<?php echo e($section->name); ?>">
                            <h1 class="text-2xl">Section <b><?php echo e($section->name); ?></b></h1>
                            <h3 class="text-lg"><?php echo nl2br(e($section->description)); ?></h3>
                        </div>
                        <?php
                            $index=0;
                        ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $section->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $index++;
                            ?>
                            <div class="bg-white p-4 rounded-3 w-full flex justify-center items-start rounded">
                                <input type="hidden" name="sections[<?php echo e($section->id); ?>][questions][<?php echo e($question->id); ?>][question]" value="<?php echo e($question->id); ?>">
                                <input type="hidden" name="sections[<?php echo e($section->id); ?>][questions][<?php echo e($question->id); ?>][question_id]" value="<?php echo e($question->id); ?>">
                                <input type="hidden" name="sections[<?php echo e($section->id); ?>][questions][<?php echo e($question->id); ?>][input_type]" value="<?php echo e($question->input_type); ?>">
                                <h4 class="numbering"><?php echo e($index); ?>.</h4>
                                <div class="flex justify-start items-center w-full flex-col ms-2">
                                    <div class="flex flex-col w-full p-2 rounded mb-2" style="background-color:rgba(0, 0, 0, 0.10);">
                                        <!--[if BLOCK]><![endif]--><?php if($question->image): ?>
                                            <div class="flex">
                                                <img src="<?php echo e($question->image); ?>" alt="" class="rounded" style="width:50%;height:auto;" loading="lazy">
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <p class="p-1 rounded" style="background-color:rgba(0, 0, 0, 0);"><?php echo e($question->question); ?></p>    
                                    </div>
                                    
                                    <div class="flex flex-col w-full">
                                        <!--[if BLOCK]><![endif]--><?php if($question->input_type == 'pilgan'): ?>
                                            <?php
                                                $pilgan='a';
                                            ?>

                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="mb-2">
                                                    
                                                    <label class="answer-box flex justify-start items-start rounded p-2 w-full cursor-pointer" 
                                                        for="answer-<?php echo e($question->id); ?>-<?php echo e($loop->index); ?>">
                                                        
                                                        
                                                        <input class="hidden answer-radio" 
                                                            type="radio" 
                                                            id="answer-<?php echo e($question->id); ?>-<?php echo e($loop->index); ?>"
                                                            name="sections[<?php echo e($section->id); ?>][questions][<?php echo e($question->id); ?>][answer]"  
                                                            value="<?php echo e($answer->id); ?>"
                                                            required>

                                                        
                                                        <h6 class="me-2 mb-0"><b><?php echo e($pilgan++); ?>.</b></h6>

                                                        <div class="flex flex-col w-full">
                                                            <!--[if BLOCK]><![endif]--><?php if($answer->image): ?>
                                                                <img src="<?php echo e($answer->image); ?>" alt="" class="rounded mb-2" style="width:150px; height:auto;" loading="lazy">
                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                            <span><?php echo e($answer->answer); ?></span>
                                                        </div>
                                                    </label>
                                                </div>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["sections.{$section->id}.questions.{$question->id}.answer"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-red-800"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                            
                                        <?php elseif($question->input_type == 'text'): ?> 
                                            
                                            <input type="text" 
                                                class="form-control" 
                                                id="answer-<?php echo e($question->id); ?>-text" 
                                                name="sections[<?php echo e($section->id); ?>][questions][<?php echo e($question->id); ?>][answer]" 
                                                placeholder="Tuliskan jawaban Anda" 
                                                aria-label="Text input for following question" required>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <div class="bg-white p-4 rounded w-full text-center">
                        <button type="submit" class="bg-green-600 p-3 px-5 rounded font-bold text-white">Submit</button>
                    </div>
                </form>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    <?php else: ?>
        <div class="flex flex-col gap-3 bg-red-300 p-4 px-6 rounded justify-center items-center text-black font-bold">
            Tidak ada form untuk sesi ini

            <!--[if BLOCK]><![endif]--><?php if($page == 'interaktif'): ?>
                <a href="<?php echo e(route('interaktif')); ?>" class="bg-green-600 p-3 px-5 rounded font-bold text-white mt-4">Lanjutkan</a>
            <?php elseif($page == 'emodul'): ?>
                <a href="<?php echo e(route('emodul')); ?>" class="bg-green-600 p-3 px-5 rounded font-bold text-white mt-4">Lanjutkan</a>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->  
</div>
<?php /**PATH C:\laragon\www\test-web-admin\resources\views/livewire/formTest/form-test.blade.php ENDPATH**/ ?>