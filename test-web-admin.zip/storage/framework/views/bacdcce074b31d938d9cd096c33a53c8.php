<div class="p-4 sm:ml-64 flex justify-center items-center flex-col" x-data="{ open: <?php if ((object) ('isModalOpen') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('isModalOpen'->value()); ?>')<?php echo e('isModalOpen'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('isModalOpen'); ?>')<?php endif; ?> }">
<?php if (isset($component)) { $__componentOriginal50c4b79f45ebbaf745fc521f681493a1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50c4b79f45ebbaf745fc521f681493a1 = $attributes; } ?>
<?php $component = App\View\Components\Loading::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Loading::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:loading.flex' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50c4b79f45ebbaf745fc521f681493a1)): ?>
<?php $attributes = $__attributesOriginal50c4b79f45ebbaf745fc521f681493a1; ?>
<?php unset($__attributesOriginal50c4b79f45ebbaf745fc521f681493a1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50c4b79f45ebbaf745fc521f681493a1)): ?>
<?php $component = $__componentOriginal50c4b79f45ebbaf745fc521f681493a1; ?>
<?php unset($__componentOriginal50c4b79f45ebbaf745fc521f681493a1); ?>
<?php endif; ?>
        <div class="hidden" id='jsLoader'>
            <?php if (isset($component)) { $__componentOriginal50c4b79f45ebbaf745fc521f681493a1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50c4b79f45ebbaf745fc521f681493a1 = $attributes; } ?>
<?php $component = App\View\Components\Loading::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Loading::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50c4b79f45ebbaf745fc521f681493a1)): ?>
<?php $attributes = $__attributesOriginal50c4b79f45ebbaf745fc521f681493a1; ?>
<?php unset($__attributesOriginal50c4b79f45ebbaf745fc521f681493a1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50c4b79f45ebbaf745fc521f681493a1)): ?>
<?php $component = $__componentOriginal50c4b79f45ebbaf745fc521f681493a1; ?>
<?php unset($__componentOriginal50c4b79f45ebbaf745fc521f681493a1); ?>
<?php endif; ?>
        </div>
        <script>
            document.getElementById('jsLoader').classList.remove('hidden');
            setTimeout(()=>{
                document.getElementById('jsLoader').classList.add('hidden');
            },3750)
        </script>
        <!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
            <div class="fixed top-5 left-1/2 transform -translate-x-1/2 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded shadow-lg z-50">
                <div class="flex items-center justify-between gap-4">
                    <span><?php echo e(session('success')); ?></span>
                    <button type="button" class="text-green-700 hover:text-green-900" onclick="this.parentElement.parentElement.remove()">
                        &times;
                    </button>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <!--[if BLOCK]><![endif]--><?php if(session('error')): ?>
            <div class="fixed top-5 left-1/2 transform -translate-x-1/2 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded shadow-lg z-50">
                <div class="flex items-center justify-between gap-4">
                    <span><?php echo e(session('error')); ?></span>
                    <button type="button" class="text-red-700 hover:text-red-900" onclick="this.parentElement.parentElement.remove()">
                        &times;
                    </button>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <h1 class="text-4xl font-bold dark:text-white text-black">Daftar Form</h1>
        <div class="flex flex-wrap m-6 p-5 bg-slate-200 dark:bg-slate-700 w-full rounded gap-3">
            <div class="w-full flex justify-end">
                <a href="<?php echo e(route('admin.form.detail', 'add')); ?>" class="bg-green-600 px-5 py-2 rounded shadow-sm text-white inline-block lg:text-xl">Tambah</a>
            </div>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('admin.form.detail', $form->id)); ?>" id="btn-form-<?php echo e($form->id); ?>" class="w-full">
                <div class="bg-gradient-to-r to-green-400 from-blue-600 dark:from-violet-600 dark:to-gray-800 p-4 rounded shadow-sm text-white w-full flex">
                    <div class="w-full">
                        <div class="title">
                            <h1 class="lg:text-4xl text-xl font-bold"><?php echo e($form->form_name); ?></h1>
                        </div>
                        <div class="flex flex-wrap items-start justify-center gap-2 lg:w-[70%] mt-5 text-sm lg:text-lg text-black">
                            <div class="lg:flex-[1_1_calc(25%-0.5rem)] flex-[1_1_calc(100%-0.5rem)] bg-white p-2 rounded">
                                <p class="text-sm  text-center">Form Ini Ditaruh Dimana?</p>
                                <p class="text-sm bg-blue-200 p-1 rounded text-center <?php echo e($form->placement == 'disable' ? 'text-red-600'  : ''); ?>"><?php echo e($form->placement == 'disable' ? 'form tidak aktif' : $form->placement); ?></p>
                            </div>
                            <div class="lg:flex-[1_1_calc(25%-0.5rem)] flex-[1_1_calc(100%-0.5rem)] bg-white p-2 rounded">
                                <p class="text-sm text-center">Responden Harus Sertakan Email?</p>
                                <p class="text-sm bg-blue-200 p-1 rounded text-center"><?php echo e($form->collect_email ? 'Iya' : 'Tidak'); ?></p>
                            </div>
                            <div class="lg:flex-[1_1_calc(25%-0.5rem)] flex-[1_1_calc(100%-0.5rem)] bg-white p-2 rounded">
                                <p class="text-sm text-center">Responden Cuman Boleh Mengisi Form Satu Kali?</p>
                                <p class="text-sm bg-blue-200 p-1 rounded text-center"><?php echo e($form->one_attempt ? 'Iya' : 'Tidak'); ?></p>
                            </div>
                            <div class="lg:flex-[1_1_calc(25%-0.5rem)] flex-[1_1_calc(100%-0.5rem)] bg-white p-2 rounded">
                                <p class="text-sm text-center">Apakah Form Harus Diisi?</p>
                                <p class="text-sm bg-blue-200 p-1 rounded text-center"><?php echo e($form->must_fill ? 'Iya' : 'Tidak'); ?></p>
                            </div>
                        </div>
                    </div>
                    <div>
                        <a data-popover-target="popover-hapus-form-<?php echo e($index); ?>" wire:click="setStatsAction(<?php echo e($form->id); ?>)" data-popover-placement="left">
                            <svg class="lg:w-8 lg:h-8 text-white hover:text-gray-700 cursor-pointer" aria-hidden="true" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 7h14m-9 3v8m4-8v8M10 3h4a1 1 0 0 1 1 1v3H9V4a1 1 0 0 1 1-1ZM6 7h12v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V7Z"/>
                            </svg>
                        </a> 
                        <div data-popover id="popover-hapus-form-<?php echo e($index); ?>" role="tooltip" data-popover-placement="left" class="absolute z-10 invisible inline-block text-sm dark:text-white transition-opacity duration-300 dark:bg-gray-600 border dark:border-gray-200 rounded-lg shadow-xs opacity-0 text-gray-400 border-gray-600 bg-gray-800">
                            <div class="py-2 px-3">
                                <p>Hapus Form</p>
                            </div>
                            <div data-popper-arrow></div>
                        </div>

                        <a data-popover-target="popover-copy-form-<?php echo e($index); ?>"  wire:click="copy(<?php echo e($form->id); ?>)" data-popover-placement="left">
                            <svg class="lg:w-8 lg:h-8 text-white hover:text-gray-700 cursor-pointer" aria-hidden="true" width="24" height="24" fill="none" viewBox="0 0 24 24">
                            <path stroke="currentColor" stroke-linejoin="round" stroke-width="2" d="M9 8v3a1 1 0 0 1-1 1H5m11 4h2a1 1 0 0 0 1-1V5a1 1 0 0 0-1-1h-7a1 1 0 0 0-1 1v1m4 3v10a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-7.13a1 1 0 0 1 .24-.65L7.7 8.35A1 1 0 0 1 8.46 8H13a1 1 0 0 1 1 1Z"/>
                            </svg>
                        </a>
                        <div data-popover id="popover-copy-form-<?php echo e($index); ?>" role="tooltip" class="absolute z-10 invisible inline-block text-sm dark:text-white transition-opacity duration-300 dark:bg-gray-600 border dark:border-gray-200 rounded-lg shadow-xs opacity-0 text-gray-400 border-gray-600 bg-gray-800">
                            <div class="py-2 px-3">
                                <p>Copy Form</p>
                            </div>
                            <div data-popper-arrow></div>
                        </div>
                        
                    </div>
                    
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div x-show="open" x-transition x-cloak class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[999] dark:text-white text-black">
            <div class="bg-white dark:bg-slate-700  rounded-lg p-3 lg:w-1/3 w-[70%]">
                <div class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-400 border-gray-200">
                    <h3 class="text-xl font-bold mb-4">
                        Hapus Form
                    </h3>
                    <button type="button" @click="open = false" class="text-gray-400 bg-transparent dark:hover:bg-gray-200 dark:hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center hover:bg-gray-600 hover:text-white" >
                        <svg class="w-3 h-3" aria-hidden="true" fill="none" viewBox="0 0 14 14">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                </div>
                <form wire:submit.prevent="delete">
                    <?php echo csrf_field(); ?>
                    <div class="p-4 md:p-5 space-y-2">
                        <p>Jika anda yakin ingin <span class="font-bold">MENGHAPUS</span> data ini, Ketik <span class="font-bold">"Hapus Form"</span> Di field dibawah</p>
                        <input type="text" wire:model="confirmDelete" 
                            class="dark:bg-gray-50 border dark:border-gray-300 dark:text-gray-900 text-sm rounded-lg focus:ring-blue-500 
                                focus:border-blue-500 block w-full bg-gray-800 border-gray-600 dark:placeholder-gray-400 
                                text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                        <!--[if BLOCK]><![endif]--><?php if(session()->has('error')): ?>
                            <p class="text-red-500 text-sm m-0"><?php echo e(session('error')); ?></p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <!-- Modal footer -->
                    <div class="flex items-center p-4 md:p-5 border-t dark:border-gray-200 rounded-b border-gray-600">
                        <button type="submit" class="text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800">Hapus</button>
                    </div>
                </form>
            </div>
        </div>
</div>
<?php /**PATH C:\laragon\www\test-web-admin\resources\views/livewire/admin/forms.blade.php ENDPATH**/ ?>