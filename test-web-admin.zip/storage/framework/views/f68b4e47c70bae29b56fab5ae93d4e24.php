<table>
    <thead>
        <tr>
            <th colspan="<?php echo e(count($uniqueAnswers) + 1); ?>" style="font-weight: bold; font-size: 16px; text-align: center;">
                REKAP JAWABAN
            </th>
        </tr>
        <tr>
            <th colspan="<?php echo e(count($uniqueAnswers) + 1); ?>" style="font-weight: bold; text-align: center;">
                Form: <?php echo e($form->form_name); ?> (<?php echo e($form->placement); ?>)
            </th>
        </tr>
        <tr></tr> <tr>
            <th style="background-color: #f0efed; font-weight: bold; width: 450px; border: 1px solid #000000; text-align: center; vertical-align: middle;">
                PERTANYAAN
            </th>
            <?php $__currentLoopData = $uniqueAnswers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th style="background-color: #e8e7e6; font-weight: bold; width: 100px; border: 1px solid #000000; text-align: center;">
                    <?php echo e($ua->answer); ?><br>
                    <small style="font-size: 9px;">VAL: <?php echo e($ua->value); ?></small>
                </th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="border: 1px solid #000000; word-wrap: break-word; vertical-align: middle;">
                    <?php echo e($row['question']); ?>

                </td>
                <?php $__currentLoopData = $uniqueAnswers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $val = $row['counts'][$ua->answer]; ?>
                    <td style="border: 1px solid #000000; text-align: center; vertical-align: middle;">
                        <?php echo e($val); ?>

                    </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laragon\www\test-web-admin\resources\views/exports/rekap-jawaban-all.blade.php ENDPATH**/ ?>